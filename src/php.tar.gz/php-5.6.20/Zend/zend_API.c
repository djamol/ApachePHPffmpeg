/*
   +----------------------------------------------------------------------+
   | Zend Engine                                                          |
   +----------------------------------------------------------------------+
   | Copyright (c) 1998-2016 Zend Technologies Ltd. (http://www.zend.com) |
   +----------------------------------------------------------------------+
   | This source file is subject to version 2.00 of the Zend license,     |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.zend.com/license/2_00.txt.                                |
   | If you did not receive a copy of the Zend license and are unable to  |
   | obtain it through the world-wide-web, please send a note to          |
   | license@zend.com so we can mail you a copy immediately.              |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@zend.com>                                |
   |          Zeev Suraski <zeev@zend.com>                                |
   |          Andrei Zmievski <andrei@php.net>                            |
   +----------------------------------------------------------------------+
*/

/* $Id$ */

#include "zend.h"
#include "zend_execute.h"
#include "zend_API.h"
#include "zend_modules.h"
#include "zend_constants.h"
#include "zend_exceptions.h"
#include "zend_closures.h"

#ifdef HAVE_STDARG_H
#include <stdarg.h>
#endif

/* these variables are true statics/globals, and have to be mutex'ed on every access */
ZEND_API HashTable module_registry;

static zend_module_entry **module_request_startup_handlers;
static zend_module_entry **module_request_shutdown_handlers;
static zend_module_entry **module_post_deactivate_handlers;

static zend_class_entry  **class_cleanup_handlers;

/* this function doesn't check for too many parameters */
ZEND_API int zend_get_parameters(int ht, int param_count, ...) /* {{{ */
{
	void **p;
	int arg_count;
	va_list ptr;
	zval **param, *param_ptr;
	TSRMLS_FETCH();

	p = zend_vm_stack_top(TSRMLS_C) - 1;
	arg_count = (int)(zend_uintptr_t) *p;

	if (param_count>arg_count) {
		return FAILURE;
	}

	va_start(ptr, param_count);

	while (param_count-->0) {
		param = va_arg(ptr, zval **);
		param_ptr = *(p-arg_count);
		if (!PZVAL_IS_REF(param_ptr) && Z_REFCOUNT_P(param_ptr) > 1) {
			zval *new_tmp;

			ALLOC_ZVAL(new_tmp);
			*new_tmp = *param_ptr;
			zval_copy_ctor(new_tmp);
			INIT_PZVAL(new_tmp);
			param_ptr = new_tmp;
			Z_DELREF_P((zval *) *(p-arg_count));
			*(p-arg_count) = param_ptr;
		}
		*param = param_ptr;
		arg_count--;
	}
	va_end(ptr);

	return SUCCESS;
}
/* }}} */

ZEND_API int _zend_get_parameters_array(int ht, int param_count, zval **argument_array TSRMLS_DC) /* {{{ */
{
	void **p;
	int arg_count;
	zval *param_ptr;

	p = zend_vm_stack_top(TSRMLS_C) - 1;
	arg_count = (int)(zend_uintptr_t) *p;

	if (param_count>arg_count) {
		return FAILURE;
	}

	while (param_count-->0) {
		param_ptr = *(p-arg_count);
		if (!PZVAL_IS_REF(param_ptr) && Z_REFCOUNT_P(param_ptr) > 1) {
			zval *new_tmp;

			ALLOC_ZVAL(new_tmp);
			*new_tmp = *param_ptr;
			zval_copy_ctor(new_tmp);
			INIT_PZVAL(new_tmp);
			param_ptr = new_tmp;
			Z_DELREF_P((zval *) *(p-arg_count));
			*(p-arg_count) = param_ptr;
		}
		*(argument_array++) = param_ptr;
		arg_count--;
	}

	return SUCCESS;
}
/* }}} */

/* Zend-optimized Extended functions */
/* this function doesn't check for too many parameters */
ZEND_API int zend_get_parameters_ex(int param_count, ...) /* {{{ */
{
	void **p;
	int arg_count;
	va_list ptr;
	zval ***param;
	TSRMLS_FETCH();

	p = zend_vm_stack_top(TSRMLS_C) - 1;
	arg_count = (int)(zend_uintptr_t) *p;

	if (param_count>arg_count) {
		return FAILURE;
	}

	va_start(ptr, param_count);
	while (param_count-->0) {
		param = va_arg(ptr, zval ***);
		*param = (zval **) p-(arg_count--);
	}
	va_end(ptr);

	return SUCCESS;
}
/* }}} */

ZEND_API int _zend_get_parameters_array_ex(int param_count, zval ***argument_array TSRMLS_DC) /* {{{ */
{
	void **p;
	int arg_count;

	p = zend_vm_stack_top(TSRMLS_C) - 1;
	arg_count = (int)(zend_uintptr_t) *p;

	if (param_count>arg_count) {
		return FAILURE;
	}

	while (param_count-->0) {
		zval **value = (zval**)(p-arg_count);

		*(argument_array++) = value;
		arg_count--;
	}

	return SUCCESS;
}
/* }}} */

ZEND_API int zend_copy_parameters_array(int param_count, zval *argument_array TSRMLS_DC) /* {{{ */
{
	void **p;
	int arg_count;

	p = zend_vm_stack_top(TSRMLS_C) - 1;
	arg_count = (int)(zend_uintptr_t) *p;

	if (param_count>arg_count) {
		return FAILURE;
	}

	while (param_count-->0) {
		zval **param = (zval **) p-(arg_count--);
		zval_add_ref(param);
		add_next_index_zval(argument_array, *param);
	}

	return SUCCESS;
}
/* }}} */

ZEND_API void zend_wrong_param_count(TSRMLS_D) /* {{{ */
{
	const char *space;
	const char *class_name = get_active_class_name(&space TSRMLS_CC);

	zend_error(E_WARNING, "Wrong parameter count for %s%s%s()", class_name, space, get_active_function_name(TSRMLS_C));
}
/* }}} */

/* Argument parsing API -- andrei */
ZEND_API char *zend_get_type_by_const(int type) /* {{{ */
{
	switch(type) {
		case IS_BOOL:
			return "boolean";
		case IS_LONG:
			return "integer";
		case IS_DOUBLE:
			return "double";
		case IS_STRING:
			return "string";
		case IS_OBJECT:
			return "object";
		case IS_RESOURCE:
			return "resource";
		case IS_NULL:
			return "null";
		case IS_CALLABLE:
			return "callable";
		case IS_ARRAY:
			return "array";
		default:
			return "unknown";
	}
}
/* }}} */

ZEND_API char *zend_zval_type_name(const zval *arg) /* {{{ */
{
	return zend_get_type_by_const(Z_TYPE_P(arg));
}
/* }}} */

ZEND_API zend_class_entry *zend_get_class_entry(const zval *zobject TSRMLS_DC) /* {{{ */
{
	if (Z_OBJ_HT_P(zobject)->get_class_entry) {
		return Z_OBJ_HT_P(zobject)->get_class_entry(zobject TSRMLS_CC);
	} else {
		zend_error(E_ERROR, "Class entry requested for an object without PHP class");
		return NULL;
	}
}
/* }}} */

/* returns 1 if you need to copy result, 0 if it's already a copy */
ZEND_API int zend_get_object_classname(const zval *object, const char **class_name, zend_uint *class_name_len TSRMLS_DC) /* {{{ */
{
	if (Z_OBJ_HT_P(object)->get_class_name == NULL ||
		Z_OBJ_HT_P(object)->get_class_name(object, class_name, class_name_len, 0 TSRMLS_CC) != SUCCESS) {
		zend_class_entry *ce = Z_OBJCE_P(object);

		*class_name = ce->name;
		*class_name_len = ce->name_length;
		return 1;
	}
	return 0;
}
/* }}} */

static int parse_arg_object_to_string(zval **arg, char **p, int *pl, int type TSRMLS_DC) /* {{{ */
{
	if (Z_OBJ_HANDLER_PP(arg, cast_object)) {
		zval *obj;
		MAKE_STD_ZVAL(obj);
		if (Z_OBJ_HANDLER_P(*arg, cast_object)(*arg, obj, type TSRMLS_CC) == SUCCESS) {
			zval_ptr_dtor(arg);
			*arg = obj;
			*pl = Z_STRLEN_PP(arg);
			*p = Z_STRVAL_PP(arg);
			return SUCCESS;
		}
		efree(obj);
	}
	/* Standard PHP objects */
	if (Z_OBJ_HT_PP(arg) == &std_object_handlers || !Z_OBJ_HANDLER_PP(arg, cast_object)) {
		SEPARATE_ZVAL_IF_NOT_REF(arg);
		if (zend_std_cast_object_tostring(*arg, *arg, type TSRMLS_CC) == SUCCESS) {
			*pl = Z_STRLEN_PP(arg);
			*p = Z_STRVAL_PP(arg);
			return SUCCESS;
		}
	}
	if (!Z_OBJ_HANDLER_PP(arg, cast_object) && Z_OBJ_HANDLER_PP(arg, get)) {
		int use_copy;
		zval *z = Z_OBJ_HANDLER_PP(arg, get)(*arg TSRMLS_CC);
		Z_ADDREF_P(z);
		if(Z_TYPE_P(z) != IS_OBJECT) {
			zval_dtor(*arg);
			Z_TYPE_P(*arg) = IS_NULL;
			zend_make_printable_zval(z, *arg, &use_copy);
			if (!use_copy) {
				ZVAL_ZVAL(*arg, z, 1, 1);
			}
			*pl = Z_STRLEN_PP(arg);
			*p = Z_STRVAL_PP(arg);
			return SUCCESS;
		}
		zval_ptr_dtor(&z);
	}
	return FAILURE;
}
/* }}} */

static const char *zend_parse_arg_impl(int arg_num, zval **arg, va_list *va, const char **spec, char **error, int *severity TSRMLS_DC) /* {{{ */
{
	const char *spec_walk = *spec;
	char c = *spec_walk++;
	int check_null = 0;

	/* scan through modifiers */
	while (1) {
		if (*spec_walk == '/') {
			SEPARATE_ZVAL_IF_NOT_REF(arg);
		} else if (*spec_walk == '!') {
			check_null = 1;
		} else {
			break;
		}
		spec_walk++;
	}

	switch (c) {
		case 'l':
		case 'L':
			{
				long *p = va_arg(*va, long *);

				if (check_null) {
					zend_bool *p = va_arg(*va, zend_bool *);
					*p = (Z_TYPE_PP(arg) == IS_NULL);
				}

				switch (Z_TYPE_PP(arg)) {
					case IS_STRING:
						{
							double d;
							int type;

							if ((type = is_numeric_string(Z_STRVAL_PP(arg), Z_STRLEN_PP(arg), p, &d, -1)) == 0) {
								return "long";
							} else if (type == IS_DOUBLE) {
								if (c == 'L') {
									if (d > LONG_MAX) {
										*p = LONG_MAX;
										break;
									} else if (d < LONG_MIN) {
										*p = LONG_MIN;
										break;
									}
								}

								*p = zend_dval_to_lval(d);
							}
						}
						break;

					case IS_DOUBLE:
						if (c == 'L') {
							if (Z_DVAL_PP(arg) > LONG_MAX) {
								*p = LONG_MAX;
								break;
							} else if (Z_DVAL_PP(arg) < LONG_MIN) {
								*p = LONG_MIN;
								break;
							}
						}
					case IS_NULL:
					case IS_LONG:
					case IS_BOOL:
						convert_to_long_ex(arg);
						*p = Z_LVAL_PP(arg);
						break;

					case IS_ARRAY:
					case IS_OBJECT:
					case IS_RESOURCE:
					default:
						return "long";
				}
			}
			break;

		case 'd':
			{
				double *p = va_arg(*va, double *);

				if (check_null) {
					zend_bool *p = va_arg(*va, zend_bool *);
					*p = (Z_TYPE_PP(arg) == IS_NULL);
				}

				switch (Z_TYPE_PP(arg)) {
					case IS_STRING:
						{
							long l;
							int type;

							if ((type = is_numeric_string(Z_STRVAL_PP(arg), Z_STRLEN_PP(arg), &l, p, -1)) == 0) {
								return "double";
							} else if (type == IS_LONG) {
								*p = (double) l;
							}
						}
						break;

					case IS_NULL:
					case IS_LONG:
					case IS_DOUBLE:
					case IS_BOOL:
						convert_to_double_ex(arg);
						*p = Z_DVAL_PP(arg);
						break;

					case IS_ARRAY:
					case IS_OBJECT:
					case IS_RESOURCE:
					default:
						return "double";
				}
			}
			break;

		case 'p':
		case 's':
			{
				char **p = va_arg(*va, char **);
				int *pl = va_arg(*va, int *);
				switch (Z_TYPE_PP(arg)) {
					case IS_NULL:
						if (check_null) {
							*p = NULL;
							*pl = 0;
							break;
						}
						/* break omitted intentionally */

					case IS_STRING:
					case IS_LONG:
					case IS_DOUBLE:
					case IS_BOOL:
						convert_to_string_ex(arg);
						if (UNEXPECTED(Z_ISREF_PP(arg) != 0)) {
							/* it's dangerous to return pointers to string
							   buffer of referenced variable, because it can
							   be clobbered throug magic callbacks */
							SEPARATE_ZVAL(arg);
						}
						*p = Z_STRVAL_PP(arg);
						*pl = Z_STRLEN_PP(arg);
						if (c == 'p' && CHECK_ZVAL_NULL_PATH(*arg)) {
							return "a valid path";
						}
						break;

					case IS_OBJECT:
						if (parse_arg_object_to_string(arg, p>   ONG4yH void zend_objects_prEN_PP(arg);
						if (c == 'p'if (d < LOULL:
						if (			convert_to_double_ex(arg);
				;
						break;

					case IS_ARRAY:
	t_to_ss' ?er";
		ca :rg);
						if (c == 'JECT:
					case IS_RESOURCblt:
						re	{
				double *p = va_arg(*va, double *);	}
			break;

		case 'd':
			{
				double *p = va_arg(*va, double *);

				if (check_null) {
					zend_bool *p = va_arg(*va, zend_bool *);
					*p = (Z_TYPE_P
								*p = (doub	break;
						}
						/* break omitted intentionally */

					case IS_STRING:
					const(in_LONG:
					case IS_DOUBLE:
					case IS_BOOL:
						convert_to_double_ex(arg);
						*p = Z_DVAL_PP(arg);
						break;

					case IS_ARRAY:
		onst(int typ 'JECT:
					case IS_RESOURCrlt:
						re	ount>are *p = va_arg(*vptr, param_			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg)ULL:
						}
}
						}
ck_null) {
					zen;
						o		*p = ( (Z_T zen						}NOT_REF(arg "string";
		case IS_OB 'JECT:
					case I_RESOURCA:
					defaalt:
						re	ount>are *p = va_arg(*vptr, param_			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg)ULL:
						}
}
						}
ck_null) {
					zendoublf deft_to_sA'g);
		ck_null) {
					zenPP(arg,o		*p = ( (Z_T zen						}NOT_REF(arg "string";		case IS_ 'JECT:
					case I_RESOURCH:
					defahlt:
						re statics/g>are *p = va_arg(* statics/g>aaram_			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg)ULL:
						}
}
						}
ck_null) {
					zendoublo		*p = ( (Z_TZndouLE:
					case IS_Z_STRLEN_ft_to_sH'g);
		ck_null) {
					zenPP(arg,		*p = ( (Z_THASH_OFLS_CC);
		Zval **p&EG(objects_strg "string";		case IS_ 'red befoNOT_REF(arg "string";		case IS_ 'JECT:
					case I					defaolt:
						re	ount>are *p = va_arg(*vptr, param_			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg)ULL:
						}
}
						}
ck_null) {
					zenPP(arg,		*p = ( (Z_T zen						}NOT_REF(arg "string";";
		case I 'JECT:
					case I					defaOlt:
						re	ount>are *p = va_arg(*vptr, param_		name(object, class_namep = va_arg(*va, dobject, class*);	}
			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg)ULL:
						}
}
						}
ck_null) {
					zenPP(argg);_strg "(!_na deie.h"
ceofG, "Wrong(, class_npe;

			onst char *sp,o		*p = ( (Z_T zen						}NOT_REF(arg "	breaects_strg "string"CCESS) {
		z			}NOT_REF(arg ""string";";
		case I 'red before free_		case I					defaClt:
						re	{
		object, class*lookurea>ar_namep = va_arg(*va, dobject, classparam_		name(object, class_n_b	defam_pce);	}
			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (_nameYPE_PP(arg)ULL:
						}
}
		ING:
					case IS_LONG:
					caBJ_HANDLElookur(objec
							long l;
							int type;

					ookur IS_OBJECT:
			TRVAL_Po		*p = ( (_nameYPE_PP(arg}NOT_REF(arg " (_name*lookur						}
}
						_n_b	detore).object_(! (_naStanie.h"
ceofG, "Wrong( (_n		on_b	deft char *sp,o		*p = (	name(sp	fprint_impl(i0, "darg.haL) {
		) != derivbjeccan'%s, '%s' .buck", (d < LOon_b	deESS) {,hroug magic callb					case I_nameYPE_PP(arg)"string";ase I 'red before fP(*arg I_ne 'd':
			{
		sp	fprint_impl(i0, "darg.haL
					) {
		) !=, '%s' .buck", (d < Lroug magic callb					casstring";ase I 'ore fPOL:
						cree_		case I					defaflt:
						re	{
		f					info *fciamep = va_arg(*va, df					info *aram_		name(f					info_c the *fccamep = va_arg(*va, df					info_c the *aram_			}
			is_ce";
		cBJ_HT_	obj->free}
			break;

		casg);
		ck_null) {
					zend_boo		*p = (fcit));
	obj	case ISfcc->ectsi			zedobj	case ISULL:
						}
			caBJ_HANDLEf					info_PI.h"
/* }}0, fci, fcc,bj->f			is_ce";
		cBJ_HT_	IS_OBJECT:
						if (parse_argBJ_His_ce";
		cBJ_HT_o		*p = (	rg_num, zv= Eb	bre(pobj':
			{
		sp	fprint_impl(i0, "darg.haL
					)erenced,	zend_is_ce";
		cBJ_HT_oobj':
		 Z_STRis_ce";
		cBJ_HT_oobj':
		 (*spv= f (*spec_PP(arg)"string";ase I 'red befSULL:
						}NOT_REF(arg "	breis_ce";
		cBJ_HT_o		*p = (	rg_num, zv= Eb*class_obj':
			{
		sp	fprint_impl(i0, "darg.haL
					)erenced,	zend_is_ce";
		cBJ_HT_oobj':
		 Z_STRis_ce";
		cBJ_HT_oobj':
		string";ase I 'reNOT_REF(arg ""string";
					)erencedase I 'red before fre					defazlt:
						re	ount>are *p = va_arg(*vptr, param_			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg}NOT_REF(arg " (Z_T zen						}			cree_		case I					defaZlt:
						re	ount>aare *p = va_arg(*vptr, pparam_			break;

		casg);
		ck_null) {
					zend_boo		*p = ( (Z_TYPE_PP(arg}NOT_REF(arg " (Z_Tzen						}			cree_		case I			CALLABLE:
			return "callable";
	
	 (*spv= f (*spec_PPNING, "Cannot reaame;
		*class_name_lenval_ptr_dtor(&}
	return FAILURE;
}
/* }}} */

static const char *zend_pa
	requietval **arg, va_list *va, const char **exnd_ted_	case IYPE_PP(har **e_HT_	obj->fre
		cag_num, zv= Eb*class_ob
	exnd_ted_	case Ival_ptr_dtor(&z);
	}turn FAIL/* }}} , end_pa&_impl(i&g_num, zval **ar {
		i	breexnd_ted_	cas_walk++;
	!quietv);
(*exnd_ted_	caseStaJ_HT_o/') {
		 }}} */

ZEND_API v	void zend_wrong_param_count(TSRMLS_D) /* {{{ */
{
	const char *space;k++;
	J_HT_o		*p =  Z_OBJ_HT_Pg_num, z, "&space T exnd_tset_active_c%d	zend IS_STRIS_CC);

	zend_error(E_WARNING, "Wrong parameter coun,eturn FAILJ_HT_oobj':
 Z_STRJ_HT_oobj':}NOT_REF(arg  Z_OBJ_HT_Pg_num, z, "&space T exnd_tset_active_c%d	darg.h%s, %s .buck", (d < LIS_CC);

	zend_error(E_WARNING, "Wrong parameter coun,eturn FAILJxnd_ted_	cas,bj':
			{
		;
		default:
		*allb					c} zend_++;
	g_num, zv!= Eb	bre(po		*p =rg_count = (int)(end_end_**)(p-arg_count);

		*(argument_array++) = valutr_dtot_active_}
	re largpa
	return FAval **arg,ILURE;
}
/* }}onst char **specmany peters */

stvare
		car/
	zv
	requietv=ementin&_ucharPARSErPARAMS_QUIET;end_uintptr_} , end_ore_pute Ival_ptr_dtor(&}turn FAIL/* }}&} , &specmaquietval **ar {
		iam = vava)xy_clone TSRMLers *zend_ge+) = valutr_dtop = vaesn't  FA= vae}}onst char **efaulspecma} */

static 
	re largval **arg, va_list *va, const cchar **spec, chaDC) /* {,re_m) /* min_ FA= vae ;
	s_m) /* max_ FA= vae ;
0_m) /* **modv_acvae ;
0_m)URE;
}
/* int zend_get_parame
	requietv=ementin&_ucharPARSErPARAMS_QUIET;e		{
				doue <sdv_acvae ;
0_m)URE;
}
>argacvae ;
j->fre
		ca*n_rgacvae ;
j->frect_storspec, char *efaulspec;**spec, chaD f (*spec_wacheck_neverity TSRMLt)(e!') {
			check__null = 1; _RESOURCE:
				default ESOURCblt:
		ESOURCrlt 		defaalt:
				defaolt 		defaOlt:
				defazlt 		defaZlt:
				defaClt 		defahlt:
				defaflt ESOURCA:
			RESOURCH:
 ESOURCE:
					max_ FA= vaewalk  fPOL:
						cESOURC|:
					min_ FA= vae ;
max_ FA= vaelk  fPOL:
						cESOURC/:
			RESOURC!:
					dleras variableOL:
						cESOURC*:
			RESOURC+:
					ect_bu<sdv_acvaeparse_argBJ_H!quieto		*p = (	name(SUCCESS;
*WARNING, "Wrong			\
	ctor */ator_iterator)->, "Wrong zende., "Wrong; IS_STRING zend_wrong_param_counWARNING, "Wrong->common.scoase?nWARNING, "Wrong->common.scoasESS) { :rg"obj':
			{
		st char *class_nam&space T: only proxrgacvae ity ec;
	
(*unctacho ve[han			*", (d < LOLIS_CC);

	z (d < LOLIS_CC);

	[0] ?er::a :rg", (d < LOLWARNING, "Wrong->common., "Wrong para)se I 'red befSrg_count = (int)(e'red befe <sdv_acvae ;
e_stora				eLJxnd_tile enset proxt_active_cinxrgacvae ariablebject_to_s+
							}
max_ FA= vaewalk  fP}stora			marka copbeginnce, ofxrgacvae ariable**modv_acvae ;
max_ FA= vaelk  fPOL:
						c
					case ISBJ_H!quieto		*p = (name(SUCCESS;
*WARNING, "Wrong			\
	ctor */ator_iterator)->, "Wrong zende., "Wrong; IS_STING zend_wrong_param_counWARNING, "Wrong->common.scoase?nWARNING, "Wrong->common.scoasESS) { :rg"obj':
		{
		st char *class_nam&space T: b{
		caseity ec;
	
 = *sp space, arg_count-", (d < LOoS_CC);

	z (d < LOIS_CC);

	[0] ?er::a :rg", (d < LOWARNING, "Wrong->common., "Wrong para)se I '}storarg_count = (int)(end_end_BJ_Hmin_ FA= vae <= is_nummin_ FA= vae ;
max_ FA= vaelk end_BJ_Hbu<sdv_acvaeparse_L,				culexechowoptimintryi		   vae 

#ile LICEd ar.      ity ec;
	
/

stariab**modv_acvae ;
max_ FA= vae - **modv_acvaet)(emax_ FA= vae ;
-1lk end_BJ_H FA= vae <=min_ FA= vae  def FA= vae >
max_ FA= vae );
max_ FA= vae >				conveBJ_H!quieto		*p =name(SUCCESS;
*WARNING, "Wrong			\
	ctor */ator_iterator)->, "Wrong zende., "Wrong; IS_ING zend_wrong_param_counWARNING, "Wrong->common.scoase?nWARNING, "Wrong->common.scoasESS) { :rg"obj':	{
		st char *class_nam&space T exnd_tse%s %d arg_count%s, %d .buck", (d < oS_CC);

	z (d < IS_CC);

	[0] ?er::a :rg", (d < WARNING, "Wrong->common., "Wrong para, (d < min_ FA= vae ;;
max_ FA= vae ?erexWARlya :r FA= vae <=min_ FA= vae ?erle enseta :rg)* m*mo", (d <  FA= vae <=min_ FA= vae ?emin_ FA= vae :
max_ FA= vae, (d < ( FA= vae <=min_ FA= vae ?emin_ FA= vae :
max_ FA= vae					1 ?era :rgs", (d <  FA= vae)} else irg_count = (int)(zend
{
	void **p;
	int arg_count;

	p =(rgument_array TSRMLS_DC) /* {{{_proxy_ob FA= vae >	RMLS_C) - 1;
	a	{
		st char *class_nam&s T: _C)l.com/l did nozed Extende_sto space,", (d r(E_WARNING, "Wrong parameter count f irg_count = (int)(zendi ;
0_m) = *spe FA= vae-- >			walk++;
	iefaulspec_to_s|
							efaulspecwalk  re			+;
	iefaulspec_to_s*'  deiefaulspec_to_s+
							n't  FA=v_acvae ;
 FA= vae +	1 - **modv_acvaet) zend_ce)* up     p_CChe obj during eucketurn  wo }}}bf thelhe objbjectrgacvae ariablv_acvae ;
p = va_arg(*vptr, ppparam_	n_rgacvae ;
:
		case 's':
			{
				efaulspecwalke;k++;
	 FA=v_acvae >= is_numer:
		ivobj	case I	ount>are *) {
		retu(rgument_array TSRMLS_DC) /* {{{ {{ FAILURE;
 {{i)*);	}
		*n_rgacvae ;
 FA=v_acvae);	}
		d_cif ZEND_end_erect TSD_APIcludnd_end_vae ariableargacvae ;
safe_xy(zval  FA=v_acvae, eobject,{
		ret,= icase I = *spe FA=v_acvae-- >			walk+ < (argacvae)[iv++]-argwalk  fP}s	}
		d_cidju zehowoptimicvae  &EG <stleftIcludrentptr loop ariable FA= vae ;
 FA= vae +	1 - ivram_			 += ivram_		std;in{
		zv:}NOT_REF(arg argacvae ;
j->fre

		*n_rgacvae ;
0				c} zend	zval e *) {
		retu(rgument_array TSRMLS_DC) /* {{{ {{ FAILURE;
-i)*);	}
BJ_HANDLEtr_dtor(&}
+1IL/* }}} , &efaulspecmaquietval **ar {

			TRVAL_Po		*p =L,		t(in up rgacvae SD_APIturn  was/* VarariablBJ_Hrgacvae );
*v_acvaeparse_ar Z_STR*v_acvaep;(arg argacvae ;
j->fre

	}*p =rg_count = (int)(end_	iwalk == '**)(p-arg_count);

		*(argume--------RETURN modZERO_ARGS( FA= vae}}efaulspecmaquietpar \e
		ca__ FA= vae ;
( FA= vae)} \e
\oxy_ob0
			(efaulspec)[0] );
0v!= __ FA= vae );
!(quietppar \e
_ING zend_wro__ND_API \e
_ING zend_wro __ng_param_count(TSRMLS_D) /* {{{ */
{__ND_APval **ar {
	 \e
_	{
		st char *class_nam&space T exnd_tseexWARly
0vzed Extend, %d .buck", \e
_	__ng_param_c, __ND_AP, \e
_	r(E_WARNING, "Wrong parameter coun,e__ FA= vae
	 \e
_rg_count = (int \e
}\read property+) = valutr_dtot_active_esn't che largpa
	re FA= vae al **arg,ILonst char **efaulspecmany parameters */
ZE */

stvare
		car/
nd_proxRETURN modZERO_ARGS( FA= vae}}efaulspecmamentin&_ucharPARSErPARAMS_QUIET);end_uintptr_} , efaulspec)re_put(nee Ival_ptr_dtop = vaes FA= vae}}efaulspecma&} ,  largval **ar {
		iam = vava)xy_clone TSRMLS_CC);

		*(argument_array++) = valutr_dtot_active_esn't  FA= vae al **arg,ILonst char **efaulspecmany parameters */
ZE */

stvare
		car/
nd_proxRETURN modZERO_ARGS( FA= vae}}efaulspecma0);end_uintptr_} , efaulspec)re_put(nee Ival_ptr_dtop = vaes FA= vae}}efaulspecma&} , 0val **ar {
		iam = vava)xy_clone TSRMLS_CC);

		*(argument_array++) = valutr_dto/* getot_active_esn't  FA= vae al **arg,IL {
		rturn__staronst char **efaulspecmany parameters */
ZE */

stvare
		car/
nd_pr_ING zend_wropr *efaulspec;m)URE;
}
= emalloc(ame(object, class_nproxy_ob!turn__stparse_RETURN modZERO_ARGS( FA= vae}}pma0);endd_uintptr_} , efaulspec)re__put(nee Ival_ptr_dtop = vaes FA= vae}}efaulspecma&} , 0val **ar {
		iiam = vava)xy:}NOT_REF(argwalk  RETURN modZERO_ARGS( FA= vae}}pma0);endd_uintptr_} , efaulspec)renddct *pobj :
		casrg(*vptr, param__namep = va_rg(*va, dobject, class*);	d_proxy_r *eurn__st);	}
BJ_H_na);
!ie.h"
ceofG, "Wrong(, class_n(turn__stp		onst char *sp,		*p =name(st char Cc zeobject)-%s::ce T mu zeb= derivbjeccan'%s::ce", (d <ceESS) {,hr(E_WARNING, "Wrong parameter coun,e, class_n(turn__stpESS) {,hr(E_WARNING, "Wrong parameter coun)lk  re			put(nee Ival_ptr_dtop = vaes FA= vae}}pma&} , 0val **ar {
		iiam = vava)xy:}_clone TSRMLS_CC);

		*(argument_array++) = valutr_dto/* getot_active_esn't che largpa
	re FA= vae al **arg,IL {
		rturn__staronst char **efaulspecmany parameters */
ZE */

stvare
		car/
nd_pr_ING zend_wropr *efaulspec;m)URE;
}
= emalloc(ame(object, class_nprv
	requietv=ementin&_ucharPARSErPARAMS_QUIET;endy_ob!turn__stparse_RETURN modZERO_ARGS( FA= vae}}pmaquietp;endd_uintptr_} , efaulspec)re__put(nee Ival_ptr_dtop = vaes FA= vae}}efaulspecma&} ,  largval **ar {
		iiam = vava)xy:}NOT_REF(argwalk  RETURN modZERO_ARGS( FA= vae}}pmaquietp;endd_uintptr_} , efaulspec)renddct *pobj :
		casrg(*vptr, param__namep = va_rg(*va, dobject, class*);	d_proxy_r *eurn__st);	}
BJ_H_na);
!ie.h"
ceofG, "Wrong(, class_n(turn__stp		onst char *sp,		*p =BJ_H!quieto		*p = name(st char Cc zeobject)-%s::ce T mu zeb= derivbjeccan'%s::ce", (d <<ceESS) {,hr(E_WARNING, "Wrong parameter coun,e, class_n(turn__stpESS) {,hr(E_WARNING, "Wrong parameter coun)lk  	}*p =am = vava)xy: =rg_count = (int)(end			put(nee Ival_ptr_dtop = vaes FA= vae}}pma&} ,  largval **ar {
		iiam = vava)xy:}_clone TSRMLS_CC);

		*(argume class_name, space, get_active_function_name(T		ca_tr);

PI.h"n "unknow, et_ob);
	oon_naFILE_LINErg, va_list *va, cEF(parHASHT			r_REL(ZndouLE:
	callb			
	ount--hash
PI.h"ZndouLE:
	callb, eobj,e,LE:
	TR_DTO(probon_naFILE_LINErRELAY_storage,pe_name(con 		zendoubl; '**)(p-arg_count);

		*(argumezend_ge+) = valumerg_P(probj->ocount>arg_coual **arg,ILn't  FA= vae}}E */

st vae}}onst cunt--hash
	zendhash
	ze va_list *va, c				e hasam_coshC)l.ca TRING:
BP_VAR_R, G <st?arg);
			hash
	zeESSKeyLE_P(ont type TSRMLS_amep = va_ vae}}_tmp);
;e
_	{
		bject - no read hbje_htamep = va_ vae}}_{
		bject - no read h)R_PP(arg, bject));	}
/* {{{ */
{
	ibject);
	A	zend_	break	ibject), hash
	zeESarKey, hash
	zeESSKeyLE_P(o-_zval(z, bje_htOBJ_HT_P(probj->o
		MAbject), *J_HT_P(probj->object)-= Z_STRLEN_PP(arbject);
	A}_clone TSon_naHASH_APPLY_KEEPC);

		*(argume clTurn SUCCESS;
shC)l.cing
aelhe afve_c    				/* get_m to beeng
aelhevarito return pmayg
ael __Netvccan'    unectsi			zedoproxy_ro   rwise.nction_name(Tl(argumentmerg_P(probj-ies(&(*object(* statics/g>(probj-iesILn't objects_htaal **arg, va_list *va, const c	{
		bject - no read hbje_htame_DC) /* {{{ */)loc(ame(object, classold_scoase		\
	scoas			
	\
	scoas	ame, class_name_)loc(ame(hash
apply_bjec_val **) s(has_dimensiobj->obje, (apply_SUCC= vaeNDLE_P(rmerg_P(probj->, 2j;
		MAbje_ht)loc\
	scoas	ameold_scoas;endy_obobjects_ht 1;
	a	{
		hash
objects(has_dimensct)-=FREErHASHT			r(has_dimensct)-});

		*(argumezend_ge+) = Z_STupduest_entry te.h"
#roxy_hand}
/* }}is_zend_g
/* }}EXTERNint parse_arg_object_to_strinOURCONSTANT,pe_n	}
ck_null)ppp,o		*p va, dobject, classpscoase		\
	inoid zend_g)?&\
	scoas	:&CG(RMLS_D) /* {{l *zob);	}
BJ_H(pscoaspESget_nto		*p =name(object, class_name*scoas;e	re staPosiESS;
posobj':	{
		ead dimeninfo *ead ninfo					c
o		*p = _storunt--hash
PIr;

_STREXPECT zene/ato(&ceEShas_dimensninfoma&posp;(arg 
   |unt--hash
 (Z_Otor */aatorato(&ceEShas_dimensninfoma(s_array)a&pad ninfoma&posp
						if (;(arg 
   |unt--hash
moING,orwardato(&ceEShas_dimensninfoma&pospparse_argBJ_His_zend_ge			((pad ninfo->mentin&_ucharACC_	bATIC:
					g);_strg    |EXTERNi			pad ninfo->EXTERNo		*p = (			car/
	zv	m_		name(object, classold_scoase		*scoas;e	re (	rgcoase		pad ninfo->ceobj':
		stre IvZ_STupduest_te.h"
#rd}
/1robj->object)-=e (	rgcoase		old_scoas;earg ""string"r/
	zv	m_	ed befo bef (d <ce *ce = get_nt		zv:}N = *specs			
	lse irg_counvZ_STupduest_te.h"
#rd}
/1robj->object)-ss_name = ce->name;
		*claon_name(Tl(argumentupduest_entry te.h"
#s(name(object, class_bjecttic int parse_arg_object_to_strin(_bjecttic ->ce_mentin&_ucharACC_CONSTANTS_UPDATEDype =   def!CE_	bATIC_MEMBERS(_bjecttic rg);
_bjecttic ->
					c_zend_g_bject)sPZVAL(ne		*p va, dobject, classpscoase		\
	inoid zend_g)?&\
	scoas	:&CG(RMLS_D) /* {{l *zob);		name(object, classold_scoase		*scoas;e	r* }}i 0 TSRscoase		_bjecttic ;
	a	{
		hash
apply_bjec_val **) (&cbjecttic ->cte.h"
#s_terous (apply_SUCC= va
	p vZ_STupduest_te.h"
#ma(s_arra)1st char *space;k_stori ;
0_ i <
_bjecttic ->
					c_has_dimensnt_para iwacheck_
BJ_H_bjecttic ->
					c_has_dimensnterou[i]o		*p = nZ_STupduest_entry te.h"
#r&_bjecttic ->
					c_has_dimensnterou[i](i0, irobj->object)-=e}k  re			+;
	!CE_	bATIC_MEMBERS(_bjecttic rg);
_bjecttic ->
					c_zend_g_bject)sPZVAL(ncount);
		if*plke;k++;
	_bjecttic ->get_nto		*p =	umentupduest_entry te.h"
#s(_bjecttic ->get_ntrobj->object)-=e}k#+;
ZTS)-=eCG(zend_g_bject)sPterou)[(name(ount;

	p(_bjecttic ->zend_g_bject)sPterou)]-arxy(zval eobject,{
	;
		
_bjecttic ->
					c_zend_g_bject)sPZVAL(n;
#OT_R
 < IS_CC)tic ->zend_g_bject)sPterou-arxy(zval eobject,{
	;
		
_bjecttic ->
					c_zend_g_bject)sPZVAL(n;
#Oinclu	;k_stori ;
0_ i <
_bjecttic ->
					c_zend_g_bject)sPZVAL(a iwacheck_
al *a&_bjecttic ->
					c_zend_g_bject)sPterou[i];
}
						}
case IS_Bp	g);_strg _bjecttic ->get_ntr);_strg i <
_bjecttic ->get_nt->
					c_zend_g_bject)sPZVAL(r);_strg *p&EG(_bjecttic ->get_nt->
					c_zend_g_bject)sPterou[i]r);_strg CE_	bATIC_MEMBERS(_bjecttic ->get_nto[i]_strgo		*p = (n
		ifq *aCE_	bATIC_MEMBERS(_bjecttic ->get_nto[i]					cont use_copy;qct)-=e (Z_SET
case IS;qct)-=e (CE_	bATIC_MEMBERS(_bjecttic r[i]r= qPP(arg}NOT_REF(arg "n
		ifr					conEF(param_pt_oobj':
	*g_cou*r						VAL(new_tmp)_oobj':
		zval *new_tmp;rct)-=e (CE_	bATIC_MEMBERS(_bjecttic r[i]r= r						}			cree_}ce;k_stori ;
0_ i <
_bjecttic ->
					c_zend_g_bject)sPZVAL(a iwacheck_
nZ_STupduest_entry te.h"
#r&CE_	bATIC_MEMBERS(_bjecttic r[i]le_zvirobj->object)-=}0 TSRscoase		old_scoas;ear_bjecttic ->ce_mentin|=_ucharACC_CONSTANTS_UPDATEDe";
		case IS_ARRAY:
			rets_arrbject -has_dimensnin.h"nandle;
} zes alreadyname(object, class_bjecttic arg_object_to_st }}i 0 TBJ_H_bjecttic ->
					c_has_dimensnZVAL(ncount alreaEShas_dimensnterou-arxy(zval eobject,{
	;
		
_bjecttic ->
					c_has_dimensnZVAL(n;e;k_stori ;
0_ i <
_bjecttic ->
					c_has_dimensnt_para iwacheck_
 alreaEShas_dimensnterou[i]r= _bjecttic ->
					c_has_dimensnterou[i];ck_
BJ_H_bjecttic ->
					c_has_dimensnterou[i]o		*#+;
ZTS)-=enEF(param_pt  alreaEShas_dimensnterou[i]ct)-=e /* {{COPYram_pt&_bjecttic ->
					c_has_dimensnterou[i](i alreaEShas_dimensnterou[i]ct)#OT_R
 < nt use_copy; alreaEShas_dimensnterou[i]ct)#Oinclu	;k} zend_+ alreaEShas_dimens ;
j->fre
});

		*(argume clTurn SUCCESS;
ntryi		s 'has_dimens't PHP nid noael has_s de_bjrhe objor i		
_bjec      el has_s bece, aublic.//wwonly a----ERNiis .buckunct    	bjeci		
 to hastd_tedAbject)st   nct without PHmerg_     pas_dimens nded exely byi		
_ elce, umentmerg_P(probj-ies().nction_name(T		ca_bject -a
		ead dimensnin.h"n "unknow, name(object, class_bjecttic (* statics/g>(probj-iesoon_naFILE_LINErg,int parse_arg_object_to_snandle;
} zes alrea 0 TBJ_H_bjecttic ->ce_mentin&_(ucharACC_INTERFACE|ucharACC_IMPLIC(neABSTRACT_CLASS|ucharACC_EXPLIC(neABSTRACT_CLASSne		*p nd_wrowurce=  |(_bjecttic ->ce_mentin&_ucharACC_INTERFACE)          |
   |?type) rface"_strg  :n(_bjecttic ->ce_mentin&_ucharACC_TRAIType =ucharACC_TRAITyp?tytrait"_strg  :                                                              "abstra ze	zend_;urn Z_OBJ_HT_P(zobject)->anom/lie.h"
tte te%s %end_wurc, _bjecttic ->para)se }ce;
	conupduest_entry te.h"
#s(_bjecttic st char *space;e,pe_name(con 		zenPP(arg; TBJ_H_bjecttic ->c zend_proxy_r G(objects_st, claLE:
	callbe Ival_pVAL_PP(_new(&ject)->get_clatic st char *spacreturn as_dimenscheck_
 alreaEShas_dimense		pad dimens;ck_
 alreaEShas_dimensnterou ;
j->fre

}NOT_REF(argbject -has_dimensnin.h"ject)->get_clatic )} else }NOT_REF(ar, claLE:
	callbe I_bjecttic ->c zend_proxy_(_bjecttic st char *spac-ss_name = ***);
		*param = (zval **) p-(arg_cobject -in.hato(n "unknow, name(object, class_bjecttic oon_naFILE_LINErg,int parse_arg_object_to_sname = _bject -a
		ead dimensnin.h"/* }}objecttic (*obon_naFILE_LINErRELAY_stst char *spacparam = (zval **) p-(arg_cobject -in.h(n "unknowoon_naFILE_LINErg,int parse_arg_object_to_sname = _bject -in.hato(now, name(s		*p = (objectstanon_naFILE_LINErRELAY_stst char *spacparam = (zval **) p-(arg_c
		zjecocG, "Wrong(n "unknow, ING zend_wrokey, s_arr(*, "Wrong _stp(INTERNE:
FUNCTIONrPARAMETERSne	g_object_to_snandlst char *class_nam
		zjecocG, "Wrong(cho vno

	swer---ppor		*");	*p = Z_STRVAL_PP(arg);
			retu **) p-(arg_c
		zjecocG	case ISn "unknow, ING zend_wrokey, et_obkey||
		Z	}

	ne	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	/* i	*n,	nexy_clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocG	case ISn "unknow, ING zend_wrokey, et_obkey||
	e	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_j->fi	*new__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocG		doe ISn "unknow, ING zend_wrokey, et_obkey||
		Zt_obbe	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	casi	*n,	bew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocG
		case e ISn "unknow, ING zend_wrokey, et_obkey||
		Zt_obre	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_;
						i	*n,	rew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocGase IS_LONn "unknow, ING zend_wrokey, et_obkey||
		Z	}

				e	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_ntentii	*n,	dew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocGase IS_LONn "unknow, ING zend_wrokey, et_obkey||
		Zhar **stl(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breaki	*n,	stl(iduplicuesew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocGase ISl_LONn "unknow, ING zend_wrokey, et_obkey||
		Zhar **stl(iet_obCE_P(o(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breakLi	*n,	stl(iCE_P(o(iduplicuesew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zjecocGnZ_STLONn "unknow, ING zend_wrokey, et_obkey||
		Zn "unkJ_HT_n";
	}
}
/* }}} */

ZEND_APsym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &J_HT_P(eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		z*param	}

"n "unknow, e	}

	*para	Z	}

	ne	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	/* i	*n,	nexy_clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram	cas"n "unknow, e	}

	*parae	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_j->fi	*new__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram		do"n "unknow, e	}

	*para	Zt_obbe	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	casi	*n,	bew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram
		case "n "unknow, e	}

	*para	Zt_obre	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_;
						i	*n,	rew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram	}

		"n "unknow, e	}

	*para	Z	}

				e	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_ntentii	*n,	dew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram		return 1;
	now, e	}

	*para	Zonst char **stl(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breaki	*n,	stl(iduplicuesew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram		retulrn 1;
	now, e	}

	*para	Zonst char **stl(iet_obCE_P(o(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breakLi	*n,	stl(iCE_P(o(iduplicuesew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zPIaram	zval_ 1;
	now, e	}

	*para	Zn "unkJ_HT_n";
	}
}
/* }}} */

ZEND_APhash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &J_HT_P(eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param	}

"n "unknow, 	}

	ne	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	/* i	*n,	nexy_clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param	cas"n "unknowe	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_j->fi	*new__clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param		do"n "unknow, t_obbe	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	casi	*n,	bew__clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param
		case "n "unknow, t_obre	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_;
						i	*n,	rew__clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param	}

		"n "unknow, 	}

				e	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_ntentii	*n,	dew__clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param		return 1;
	now, onst char **stl(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breaki	*n,	stl(iduplicuesew__clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param		retulrn 1;
	now, onst char **stl(iet_obCE_P(o(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breakLi	*n,	stl(iCE_P(o(iduplicuesew__clone TSname(hash
val **paraminserh"ZndouLE:
	callb, &	*n,	eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zval **param	zval_ 1;
	now, n "unkJ_HT_n";
	}
}
/* }}} */

ZEND_APhash
val **paraminserh"ZndouLE:
	callb, &J_HT_P(eobject,{
		r),bj->fpacparam = (zval **) p-(arg_c
		zr(E_WecocGase IS_LONn "unknow, ING zend_wrokey, et_obkey||
		Zhnst char **stl(is_arrayobje(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breaki	*n,	stl(iduplicuesew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bobjepacparam = (zval **) p-(arg_c
		zr(E_WecocGase ISl_LONn "unknow, ING zend_wrokey, et_obkey||
		Zhnst char **stl(iet_obCE_P(o(is_arrayobje(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breakLi	*n,	stl(iCE_P(o(iduplicuesew__clone TSname(sym) {
		updues"ZndouLE:
	callb, key, key||
		Z(s_arra) &	*n,	eobject,{
		r),bobjepacparam = (zval **) p-(arg_c
		zr(E_*param	}

"n "unknow, e	}

	*para	Z	}

	l(is_arrayobjee	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	/* i	*n,	lew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bobjepacparam = (zval **) p-(arg_c
		zr(E_*param	}

		"n "unknow, e	}

	*para	Z	}

				(is_arrayobjee	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_ntentii	*n,	dew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bobjepacparam = (zval **) p-(arg_c
		zr(E_*param		return 1;
	now, e	}

	*para	Zonst char **stl(is_arrayobje(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breaki	*n,	stl(iduplicuesew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bobjepacparam = (zval **) p-(arg_c
		zr(E_*param		retulrn 1;
	now, e	}

	*para	Zonst char **stl(iet_obCE_P(o(is_arrayobje(int aduplicuese	g_object_to_sn{
		rtVAL_IS/* {{{ */
{
	i	*new_tzend_	breakLi	*n,	stl(iCE_P(o(iduplicuesew__clone TSname(hash
PIaramupdues"ZndouLE:
	callb, *para	Z(s_arra) &	*n,	eobject,{
		r),bobjepacparam = (zval **) p-(arg_c
r);

ne/anZ_STkey( statics/g>ht, n "unkkey, n "unkJ_HT_n";
	}
}
/* }}}		car/sula 0 T(*va, zend_bool (	ze check_null oub	break;
			r/sulae Ival_psym) {
		updues"ht, roug magic(	ze 						int ty(	ze  +	1, &J_HT_P(eobject,{
		r),bj->fpac				case I_RESOURE_P
								r/sulae Ival_psym) {
		updues"ht, "",	1, &J_HT_P(eobject,{
		r),bj->fpac				case I_RESOURE_P;
						breaknandlst char 	bre(p, "R		case  ID#%ld/* Varas|EXTERNZ_STRVce, top = Nwer-(%ld)", IS_LONG:(	ze 				_LONG:(	ze pac			null) {
	misace,  = NULL;
							*y */

					case IS	}
						/* breakr/sulae Ival_phash
PIaramupdues"ht, ro_LONG:(	ze 		&J_HT_P(eobject,{
		r),bj->fpac				case I_RESOURE_Pntentionallr/sulae Ival_phash
PIaramupdues"ht, 			*p = LONG_MIN;
OUBLE:
	(	ze p		&J_HT_P(eobject,{
		r),bj->fpac				case I_R
					case Inandlst char *class_namIlleg
		EXTERNitic ")xy: =rgsulae It = (int)(zendif (rgsulae 					if (parse_t use_copy;J_HT_nlk == '**)(p-ar/sula 0param = (zval **) p-(arg_c
		zead dimen	case ISn "unknow, ING zend_wrokey, et_obkey||
		Z	}

	nint parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_	/* i	*n,	nexy_c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimen		doe ISn "unknow, ING zend_wrokey, et_obkey||
		Zt_obbint parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_	casi	*n,	bew__c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimen	case ISn "unknow, ING zend_wrokey, et_obkey||
	int parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_j->fi	*new__c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimen
		case e ISn "unknow, ING zend_wrokey, et_obkey||
		Z	}

	nint parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_;
						i	*n,	nexy_c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimenase IS_LONn "unknow, ING zend_wrokey, et_obkey||
		Z	}

				int parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_ntentii	*n,	dew__c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimenase IS_LONn "unknow, ING zend_wrokey, et_obkey||
		Zhnst char **stl(int aduplicuesint parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_	breaki	*n,	stl(iduplicuesew__c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimenase ISl_LONn "unknow, ING zend_wrokey, et_obkey||
		Zhnst char **stl(iet_obCE_P(o(int aduplicuesint parse_arg_object_to_sn{
		rtVAL_sn{
		rzTkeyL_IS/* {{{ */
{
	i	*new_tzend_	breakLi	*n,	stl(iCE_P(o(iduplicuesew__c/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, 	*n,	probj->object)- Z_STRLEN_PP(ar	*newrg_oJ_HT_P(probj-> willc
		 1						fZVAL(r		*y Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_c
		zead dimennZ_STLONn "unknow, ING zend_wrokey, et_obkey||
		Zn "unkJ_HT_int parse_arg_object_to_sn{
		rzTkeyL_IS/* {{{ */
{
	izTkeyew_tzend_	breakLizTkey, key, key||
	-_zval(z
	_DC) /*ANDLER
	call, J_HT_P(probj->)(now, nTkey, J_HT_P(probj->object)- Z_STRLEN_PP(arzTkeyew_tname = ***);
		*param = (zval **) p-(arg_cname(s		rtup_moduIS_LONnmentmoduIS_L classmoduISint parse_arg_object_to_st't  ame||
	PP(har **lcS) {
	d_BJ_HmoduIS->moduIS_s		rtedparse_name = ***);
		*-ss_moduIS->moduIS_s		rted ;
e_s c			Ck;

 moduISidepmenencenserg);
			moduIS->depscheck_onst c	{
		moduIS_dep *dep = moduIS->deps					 = *spedep->para)heck_
BJ_Hdep->	case = MODULE_DEP_;
QUIREDyp	*p =	umentmoduIS_L classreqtmod					co ame||
	 ;
str|
	edep->para)t)-=e lcS) {e Ival_ps;

	oloweEN_upedep->para,  ame||
	*);	}
			breval_phash
find(&moduIS_regis;
y, lcS) {,  ame||
	+1IL(s_ar**)&reqtmod

			TRVAL_PaStanreqtmod->moduIS_s		rtedparse__ar Z_STRlcS) {ct)-=e ( clTODO:	Ck;

 versSS;
ntlaLL;
ship ariable name(st char Cc ze*class_nam>anom/lload moduISi'%s' to returntryi		  moduISi'%s' o vno/lload	*", moduIS->S) {, dep->para)t)-=e _moduIS->moduIS_s		rted ;
0;d befSrg_count = (int)(e'red bef Z_STRlcS) {ct)-=eed be++dept)(end_end_ clIctsi			ze moduISiglobalserg);
			moduIS->globals_eobjo		*#+;stanoTS)-=ts_if ZEND__id	moduIS->globals_id__starmoduIS->globals_eobjIL(ts_if ZEND___tmp)rmoduIS->globals__tmpIL(ts_if ZEND__dtmp)rmoduIS->globals_dtmp)t)#OT_R
 <
			moduIS->globals__tmp)rrse__moduIS->globals__tmp	moduIS->globals__strobj->object)-=}0#Oinclu	}d_BJ_HmoduIS->moduIS_s		rtup_, "W)rrse_\
	ctor */amoduIS) = moduIS;
 <
			moduIS->moduIS_s		rtup_, "W	moduIS->tic (*moduIS->moduIS_nuect)robj->objec==TRVAL_Po		*p =name(st char Cc zeobject"Unics/g			ntptr %s*moduIS", moduIS->S) {ct)-=e\
	ctor */amoduIS) = j->fre

	rg_count = (int)(end_	\
	ctor */amoduIS) = j->fre
} '**)(p-arg_count);

		*(argumezend_gel(argumentsor/amoduISs(s_arrab	deP(eobj_t ZVAL(P(eobj_t eob, INmget__SUCC=t INmget_int parse_arg_object_to_sBucke(r	*b1 = b	de;_sBucke(r	*b2;_sBucke(r	*d ar= b1 + t_parameBucke(r	tVAL_snmentmoduIS_L classm,ifr				 = *speb1 <Ed ao		*cla_againase me *) mentmoduIS_L cla*)(*b1pESgData;
 <
			!m->moduIS_s		rted );
m->depscheck__onst c	{
		moduIS_dep *dep = m->deps					 = *spedep->para)heck_

BJ_Hdep->	case = MODULE_DEP_;
QUIREDaStadep->	case = MODULE_DEP_OPTIONAoo		*p = (b2r= b1 + e_stora	 = *speb2 <Ed ao		*arg ""se *) mentmoduIS_L cla*)(*b2pESgData;
 <k_

BJ_Hs;
ESOUcmpedep->para, r->para)h==			walk+ < -=tm(Z_T be_stora			*b1 = *b2;_sora			*b2r= tVAL_sssssssgo			cla_againL_ssssssed befS(b2walk  fPred before fPdepwalk  f} zend_+b1walk ==>name;
		*claon_name(Tl(argumentcollct -moduIS_ no readmeter coDarg_object_to_s staPosiESS;
posobjnmentmoduIS_L classmoduISre
		cag		rtup_void **p0_m) /* shutdown_void **p0_m) /* **moddeRMLS_uest_tid **p0_m)va, dobject, classpp_nprv
	re_entry tid **p0_m c			Collct  extensSS;sjbjectntryescag		rtup/shutdown  no read h/
 _storunt--hash
PIr;

_STREXPECT zene/ato(&moduIS_regis;
y, &posp;(a
   |unt--hash
 (Z_Otor */aatorato(&moduIS_regis;
y, (s_arra) &moduISma&posp
						if (;(a
   |unt--hash
moING,orwardato(&moduIS_regis;
y, &posp	walk++;
	moduIS->ntryesc_s		rtup_, "W)rrse_	g		rtup_void walk  rek++;
	moduIS->ntryesc_shutdown_, "W)rrse_	ghutdown_void walk  rek++;
	moduIS->**moddeRMLS_uest, "W)rrse_	**moddeRMLS_uest_tid walk  rekss_moduIS_ntryesc_s		rtup_ no read  *) mentmoduIS_L cla**)y(zval (a
   eobject,mentmoduIS_L cla*) *k  (g		rtup_void *+	1 +k   shutdown_void *+	1 +k   **moddeRMLS_uest_tid *+	1 pac	moduIS_ntryesc_s		rtup_ no read[g		rtup_void ] = j->fre
moduIS_ntryesc_shutdown_ no read  *moduIS_ntryesc_s		rtup_ no read + g		rtup_void *+	1re
moduIS_ntryesc_shutdown_ no read[shutdown_void ] = j->fre
moduIS_**moddeRMLS_uest no read  *moduIS_ntryesc_shutdown_ no read + shutdown_void *+	1re
moduIS_**moddeRMLS_uest no read[**moddeRMLS_uest_tid ] = j->fre
g		rtup_void **p0_m)
 _storunt--hash
PIr;

_STREXPECT zene/ato(&moduIS_regis;
y, &posp;(a
   |unt--hash
 (Z_Otor */aatorato(&moduIS_regis;
y, (s_arra) &moduISma&posp
						if (;(a
   |unt--hash
moING,orwardato(&moduIS_regis;
y, &posp	walk++;
	moduIS->ntryesc_s		rtup_, "W)rrse_	moduIS_ntryesc_s		rtup_ no read[g		rtup_void ++]-armoduIS;
 <rek++;
	moduIS->ntryesc_shutdown_, "W)rrse_	moduIS_ntryesc_shutdown_ no read[--shutdown_void ] = moduIS;
 <rek++;
	moduIS->**moddeRMLS_uest, "W)rrse_	moduIS_**moddeRMLS_uest no read[--**moddeRMLS_uest_tid ] = moduIS;
 <rek}m c			Collct  PIr;

_Se_entresjbjectzend_gebject)sth/
 _storunt--hash
PIr;

_STREXPECT zene/ato(CG(_bjectterou), &posp;(a
   |unt--hash
 (Z_Otor */aatorato(CG(_bjectterou), (s_arra) &pcSma&posp
						if (;(a
   |unt--hash
moING,orwardato(CG(_bjectterou), &posp	walk++;
	(pp_n)->	case = on_naINTERNE:
CLASSr);_st   |(pp_n)->
					c_zend_g_bject)sPZVAL(r>			walk+   |_entry tid walk  rekss
r_bject	t(inup_ no read  *) mentobject, cla**)y(zval (a	eobject,mentobject, cla*) *k  (_entry tid *+	1 pac	_bject	t(inup_ no read[_entry tid ] ;
j->frectBJ_H_bjectZVAL(ncount_storunt--hash
PIr;

_STREXPECT zene/ato(CG(_bjectterou), &posp;(aa
   |unt--hash
 (Z_Otor */aatorato(CG(_bjectterou), (s_arra) &pcSma&posp
						if (;(a
   	|unt--hash
moING,orwardato(CG(_bjectterou), &posp	walk+++;
	(pp_n)->	case = on_naINTERNE:
CLASSr);_stt   |(pp_n)->
					c_zend_g_bject)sPZVAL(r>			walk++   |_entry t(inup_ no read[--_entry tid ] ;
pp_nprv f} zend_}*param = (zval **) p-(arg_cname(s		rtup_moduISdmeter coDarg_object_to_sunt--hash
sor/(&moduIS_regis;
y, umentsor/amoduISs,bj->fP(probj->object)- {
		hash
apply(&moduIS_regis;
y, (apply_SUCC=DLE_P(rs		rtup_moduIS_LOrobj->object)-name = ***);
		*param = (zval **) p-(al(argumentobjects_moduISs(s_ararg_object_to_sZ_STR_entry t(inup_ no readct)-Z_STRmoduIS_ntryesc_s		rtup_ no readct)- {
		hash
graceful_ntverse
objects(&moduIS_regis;
ypacparam = (zval **) p-(a,mentmoduIS_L cla*a,mentregis;CT moduIS_LONnmentmoduIS_L classmoduISint parse_arg_object_to_st't  ame||
	PP(har **lcS) {
	jnmentmoduIS_L classmoduIS__st);	}
			!moduIS) rse_name = j->fre
} *#+;
0
:	{
		eat'tf(-%s: Regis;CTce, moduISi%d\n", moduIS->S) {, moduIS->moduIS_nuect)ct)#Oinclu c			Ck;

 moduISidepmenencenserg);
			moduIS->depscheck_onst c	{
		moduIS_dep *dep = moduIS->deps					 = *spedep->para)heck_
BJ_Hdep->	case = MODULE_DEP_CONFLICTS	walk+ < ame||
	 ;
str|
	edep->para)t)-=e lcS) {e Ival_ps;

	oloweEN_upedep->para,  ame||
	*);	}
			breval_phash
exis;s(&moduIS_regis;
y, lcS) {,  ame||
	+1)parse__ar Z_STRlcS) {ct)-=e ( clTODO:	Ck;

 versSS;
ntlaLL;
ship ariable name(st char Cc ze*class_nam>anom/lload moduISi'%s' to returonsflictce, moduISi'%s' o valreadylload	*", moduIS->S) {, dep->para)t)-=e _name = j->fre
e'red bef Z_STRlcS) {ct)-=eed be++dept)(end_end_ ame||
	 ;
str|
	emoduIS->S) {ct)-lcS) {e Ival_ps;

	oloweEN_upemoduIS->S) {,  ame||
	*);	}	breval_phash
add(&moduIS_regis;
y, lcS) {,  ame||
	+1IL(s_arra)moduISmaeobject,mentmoduIS_L cla)IL(s_ar**)&moduIS__stc==TRVAL_Po		*p name(st char Cc ze*class_namModuISi'%s' alreadylload	*", moduIS->S) {ct)-= Z_STRlcS) {ct)-=name = j->fre
} = Z_STRlcS) {ct)-moduISi *moduIS__st);_\
	ctor */amoduIS) = moduIS;
);
			moduIS->, "Wronge );
,mentregis;CT , "Wronge(j->fP(moduIS->, "Wronge,bj->fP(moduIS->tic robj->objec==TRVAL_Po		*p \
	ctor */amoduIS) = j->fre

name(st char Cc ze*class_n-%s: Unics/g			regis;CT , "Wronge,bunics/g			load", moduIS->S) {ct)-=name = j->fre
} * \
	ctor */amoduIS) = j->fre
name = moduIS;
param = (zval **) p-(a,mentmoduIS_L cla*a,mentregis;CT PIr;

_STmoduISNnmentmoduIS_L classmoduISint parse_arg_object_to_smoduIS->moduIS_nuect)r Ival_pval *Z_STTmoduISNct)-moduIS->	case  MODULE_PERSISTENT;_clone TSname(regis;CT moduIS_LONmoduISint pars*spacparam = (zval **) p-(al(argumentck;

_mag_g_bj getoimple**) aLL;
(onst c	{
		object, class_n}}onst cunt--SUCCESS;
*fptl(int ast chttic int parse_arg_object_to_shar *lcS) {[16];_st't  ame||
	PP c				Sido }}}cet_ii      SUCCESS;
S) {eo v
	swer(int fa zeloweEcaace, only(a
*     beginnce, o      am_cospeeds up     ck;

	padcesserg); ame||
	 ;
str|
	efptl->common., "Wrong para)se val_ps;

	oloweEN *ne(lcS) {, fptl->common., "Wrong para, MIN( ame||
	maeobjectlcS) {c-1 pac	lcS) {[eobjectlcS) {c-1] ;
'\0'wrg_oval_ps;

	oloweEN *ne wo }}}necessarily ERNit   zero byte(zval++;
	 ame||
	 ;=aeobject **) DESTRUCTOR
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) DESTRUCTOR
FUNC_NAME,aeobject **) DESTRUCTOR
FUNC_NAME* {{{rg);
fptl->common. FA= vae !=			walk+name(st chast chttic namDe	/* get_m%s::ce T canom/ltaknd_va **) s", ceESS) {,h **) DESTRUCTOR
FUNC_NAME*xy:}NOT_RE+;
	 ame||
	 ;=aeobject **) CLONE
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) CLONE
FUNC_NAME,aeobject **) CLONE
FUNC_NAME* {{{rg);
fptl->common. FA= vae !=			walk+name(st chast chttic namMj getm%s::ce T canom/lacceptIclyd_va **) s", ceESS) {,h **) CLONE
FUNC_NAME*xy:}NOT_RE+;
	 ame||
	 ;=aeobject **) GET
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) GET
FUNC_NAME,aeobject **) GET
FUNC_NAME* {{{p	walk++;
	fptl->common. FA= vae !=	1o		*p =name(st chast chttic namMj getm%s::ce T mu zetakndexWARly
1d_va **) ", ceESS) {,h **) GET
FUNC_NAME*re

}NOT_RE+;
	ARG_SHOULD_BE_SENT_BY_REF(fptl(i1)o		*p =name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s by			fer *ce", ceESS) {,h **) GET
FUNC_NAME*re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject **) SET
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) SET
FUNC_NAME,aeobject **) SET
FUNC_NAME* {{{p	walk++;
	fptl->common. FA= vae !=	2o		*p =name(st chast chttic namMj getm%s::ce T mu zetakndexWARly
2d_va **) s", ceESS) {,h **) SET
FUNC_NAME*re

}NOT_RE+;
	ARG_SHOULD_BE_SENT_BY_REF(fptl(i1)aStaARG_SHOULD_BE_SENT_BY_REF(fptl(i2)o		*p =name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s by			fer *ce", ceESS) {,h **) SET
FUNC_NAME*re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject **) UNSET
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) UNSET
FUNC_NAME,aeobject **) UNSET
FUNC_NAME* {{{p	walk++;
	fptl->common. FA= vae !=	1o		*p =name(st chast chttic namMj getm%s::ce T mu zetakndexWARly
1d_va **) ", ceESS) {,h **) UNSET
FUNC_NAME*re

}NOT_RE+;
	ARG_SHOULD_BE_SENT_BY_REF(fptl(i1)o		*p =name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s by			fer *ce", ceESS) {,h **) UNSET
FUNC_NAME*re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject **) ISSET
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) ISSET
FUNC_NAME,aeobject **) ISSET
FUNC_NAME* {{{p	walk++;
	fptl->common. FA= vae !=	1o		*p =name(st chast chttic namMj getm%s::ce T mu zetakndexWARly
1d_va **) ", ceESS) {,h **) ISSET
FUNC_NAME*re

}NOT_RE+;
	ARG_SHOULD_BE_SENT_BY_REF(fptl(i1)o		*p =name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s by			fer *ce", ceESS) {,h **) ISSET
FUNC_NAME*re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject **) CALL
FUNC_NAME* {{{ );
!bjecmpelcS) {,  **) CALL
FUNC_NAME,aeobject **) CALL
FUNC_NAME* {{{p	walk++;
	fptl->common. FA= vae !=	2o		*p =name(st chast chttic namMj getm%s::ce T mu zetakndexWARly
2d_va **) s", ceESS) {,h **) CALL
FUNC_NAME*re

}NOT_RE+;
	ARG_SHOULD_BE_SENT_BY_REF(fptl(i1)aStaARG_SHOULD_BE_SENT_BY_REF(fptl(i2)o		*p =name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s by			fer *ce", ceESS) {,h **) CALL
FUNC_NAME*re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject **) CALL	bATIC_FUNC_NAME* {{{ );e

!bjecmpelcS) {,  **) CALL	bATIC_FUNC_NAME,aeobject **) CALL	bATIC_FUNC_NAME*-1 
		walk++;
	fptl->common. FA= vae !=	2o		*p =name(st chast chttic namMj getm%s::ce T mu zetakndexWARly
2d_va **) s", ceESS) {,h **) CALL	bATIC_FUNC_NAME*re

}NOT_RE+;
	ARG_SHOULD_BE_SENT_BY_REF(fptl(i1)aStaARG_SHOULD_BE_SENT_BY_REF(fptl(i2)o		*p =name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s by			fer *ce", ceESS) {,h **) CALL	bATIC_FUNC_NAME*re

}
 :}NOT_RE+;
	 ame||
	 ;=aeobject **) TO	break_FUNC_NAME* {{{ );e 

!bjecmpelcS) {,  **) TO	break_FUNC_NAME,aeobject **) TO	break_FUNC_NAME*-{rg);
fptl->common. FA= vae !=		
		walk+name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s", ceESS) {,h **) TO	break_FUNC_NAME*xy:}NOT_RE+;
	 ame||
	 ;=aeobject **) DEBUGINFO_FUNC_NAME* {{{ );e

!bjecmpelcS) {,  **) DEBUGINFO_FUNC_NAME,aeobject **) DEBUGINFO_FUNC_NAME*-{rg);
fptl->common. FA= vae !=			walk+name(st chast chttic namMj getm%s::ce T canom/ltaknd_va **) s", ceESS) {,h **) DEBUGINFO_FUNC_NAME*re
});

		*(argume clregis;CTs  el , "Wronge in *library_, "Wronge in     SUCCESS;
hashnction_name(T		ca,mentregis;CT , "Wronge(	{
		object, classscoas}}onst cunt--SUCCESS;t, class, "Wronge,b statics/g>SUCCESS;tterous 		catic int parse_arg_object_to_shnst cunt--SUCCESS;t, class_str= , "Wrongese val_pSUCCESS;
SUCCESS;,ifregpSUCCESS;se val_pPIr;

_STSUCCESS;
*PIr;

_STSUCCESS;
 *) mentPIr;

_STSUCCESS;
*)&SUCCESS;se 
	re_tid =0,bunload=0_m) statics/g>t_vaet_SUCCESS;tterour= , "Wrongtterouse 
	rest chttic se val_pSUCCESS;
*get_m=bj->fP(*det_m=bj->fP(*clonem=bj->fP(*_
 (Zm=bj->fP(*_
s(Zm=bj->fP(*_
uns(Zm=bj->fP(*_
iss(Zm=bj->fP(*_

ael =bj->fP(*_

aelzend_ge	bj->fP(*_
toase ISe	bj->fP(*_
debugInfo = j->fre
ING zend_wroloweEcaae_S) {
	j
	ref ame||
	PP(hNG zend_wrolc	objectS) {e Ij->fre

	re_entry ame||
	 ;
0_m)va, de	}

	hash;
);
			tic ==MODULE_PERSISTENT	walk+st chttic i= r Cc ze*class_;e }NOT_REF(arst chttic i= r *class_;e };	}
			!t_vaet_SUCCESS;tterou	walk+t_vaet_SUCCESS;tterour= CG(SUCCESS;tterou	re
} =PIr;

_STSUCCESS;->	case  on_naINTERNE:
FUNCTION; =PIr;

_STSUCCESS;->moduISi *\
	ctor */amoduIS);
);
			scoas	a{ear_bject ame||
	 ;
str|
	escoas->S) {ct)-=+;
	(lc	objectS) {e Iumentmemrchrescoas->S) {, '\\',e_entry ame||
	p,o		*p 	++lc	objectS) {;
 < IS_CC) ame||
	 - *)lc	objectS) {e- scoas->S) {ct)-=	lc	objectS) {e Iuments;

	oloweEN_upelc	objectS) {,e_entry ame||
	pre

}NOT_REF(arglc	objectS) {e Iuments;

	oloweEN_upescoas->S) {, _entry ame||
	pre

}e };	} = *speptl->fpara)heck_PIr;

_STSUCCESS;-> no reae		ptl-> no rea;ck_PIr;

_STSUCCESS;->, "Wrong para
 *)nd_w*)ptl->fpara;ck_PIr;

_STSUCCESS;->scoase		scoas;e	r* };

_STSUCCESS;->hasto	case  j->fre

turn tl->fenti)heck_
BJ_H!n tl->fentin&_ucharACC_PPP_MASK))heck_

BJ_H tl->fentin! =ucharACC_DEPRECATEDaStascoas	a{earp =name(st chast chttic namInvalidlaccess level ,t_m%s%s%s(* {{access mu zebndexWARly
onemof aublic, hastd_tedAt_mprS_ues", scoase? scoas->S) { : "",	scoase? "::" : "",	ptl->fpara)re
e'red befPIr;

_STSUCCESS;->,n_mentin =ucharACC_PUBLIC |  tl->fenti		zv:}NOT_REF(arg PIr;

_STSUCCESS;->,n_mentin = tl->fenti		zv:}e

}NOT_REF(argPIr;

_STSUCCESS;->,n_mentin =ucharACC_PUBLIC;
 <rek++;
	 tl-> va
infoo		*p =name(PIr;

_STSUCCESS;ninfo *info = (name(PIr;

_STSUCCESS;ninfo*)ptl-> va
info		zv:(argPIr;

_STSUCCESS;-> va
info = (name( va
info*)ptl-> va
info+e_storPIr;

_STSUCCESS;-> FA= vae  = tl-> FA= vaeac			nulCtor */ly
t wicanom/ldeom/_   at     SUCCESS;
canlacceptIless _va **) s   an  FA= vae ariablBJ_Hinfo->ntryi		 _ FA= vae  = -1)EF(arg PIr;

_STSUCCESS;->ntryi		 _ FA= vae  = tl-> FA= vaeac			}NOT_REF(arg PIr;

_STSUCCESS;->ntryi		 _ FA= vae  =info->ntryi		 _ FA= vaet)-=eed beBJ_Hinfo->ntne T_		fer *ce)EF(arg PIr;

_STSUCCESS;->,n_mentin|=_ucharACC_RETURN_REFERENCEt)-=eed beBJ_Hptl-> va
info[ tl-> FA= vae].is_variadic)EF(arg PIr;

_STSUCCESS;->,n_mentin|=_ucharACC_VARIADIC;
 <:}e

}NOT_REF(argPIr;

_STSUCCESS;-> va
info = j->fre
e'PIr;

_STSUCCESS;-> FA= vae  =0re
e'PIr;

_STSUCCESS;->ntryi		 _ FA= vae  =0;
 <rek++;
	 tl->fentin&_ucharACC_ABSTRACT)heck_
BJ_Hscoas	a{earp  clTurn o va
_bjec   at mu zebndabstra zeitself. Her 		SiERNit   ck;

	info. ariablescoas->ce_mentin|=_ucharACC_IMPLIC(neABSTRACT_CLASS;
}
						!(scoas->ce_mentin&_ucharACC_INTERFACE)	a{earp = clSi*cet    	bjec o vno/lan pe) rfaceeitithousg			be de_bjrhe a va
abstra ze	zend. ariable= clSi*cether 		Siet_i no rce,  = N

_Se, "Wronge only 	Sicanladdt    keyword ment. ariable= clTurn tim 		SiERNit   ment ,t_m    keyword 'abstra z'. ariable=scoas->ce_mentin|=_ucharACC_EXPLIC(neABSTRACT_CLASS						}			cree_++;
	 tl->fentin&_ucharACC_	bATICg);
(!scoaseStan(scoas->ce_mentin&_ucharACC_INTERFACE)	yp	*p =	umentst chast chttic namSend_geSUCCESS;
%s%s%s(* canom/lbndabstra z", scoase? scoas->S) { : "",	scoase? "::" : "",	ptl->fpara)re
e'}e

}NOT_REF(argPJ_Hscoasg);
(scoas->ce_mentin&_ucharACC_INTERFACE)	a{earp  Z_STR)nd_w*)lc	objectS) {)re
e'rname(st chast chttic namIn) rfacee%s canom/lP nid nonS;
abstra zemj getm%s()",	scoas->S) {, ptl->fpara)re
e'rrg_count = (int)(e'ree_++;
	!PIr;

_STSUCCESS;-> no rea)heck_

BJ_Hscoas	a{earp = Z_STR)nd_w*)lc	objectS) {)re
e'r}e
e'rname(st chast chttic namMj getm%s%s%s(* canom/lbnda j->feSUCCESS;", scoase? scoas->S) { : "",	scoase? "::" : "",	ptl->fpara)re
e'rva, denregis;CT , "Wronge(, "Wronge,bZVAL(P(t_vaet_SUCCESS;tterourobj->object)-=errg_count = (int)(e'ree_ree_f ame||
	 ;
str|
	eptl->fpara)re
eloweEcaae_S) {r Ival_pvaw(PIr;

edm		returnments;

	oloweEN_upeptl->fpara,ef ame||
	),ef ame||
	 +	1, 1robj->object)-=hashn;
strphash(loweEcaae_S) {,ef ame||
	)re

turnval_phash
ryick
add(t_vaet_SUCCESS;tterou, loweEcaae_S) {,ef ame||
	+1ILhash, &SUCCESS;,ieobject,mentSUCCESS;)IL(s_ar**)&regpSUCCESS;

			TRVAL_P	a{earpunload=e_storstrp Z_STRloweEcaae_S) {pac				case I_R}0 TS clIfatic s|EX _va **) s haveg			be ck;

he ariabif (rggTSUCCESS;->common. va
info );
rggTSUCCESS;->common. FA= vae)EF(argPIr}i 0	;k_stori ;
0_ i <
rggTSUCCESS;->common. FA= vaea iwacheck_
aif (rggTSUCCESS;->common. va
info[i].objectS) {e||ck_
a   |rggTSUCCESS;->common. va
info[i].tic _hiL(ncount
a   |rggTSUCCESS;->common.,n_mentin|=_ucharACC_HASd_boolHINTS								case I_R		}			cree_}ce;kBJ_Hscoas	a{earp clLook ,t_m_tmpILdtmpILclonelk++ clIfait'c   	old-style}onst * get_,	storeeitionly BJ_	Sido }}}havelk++ cla}onst * get_ already.lk++ criablBJ_H(f ame||
	 ;=a_entry ame||
	p );
!get_ );
!bjecmpeloweEcaae_S) {,elc	objectS) {,e_entry ame||
	+1)parse__aget_m=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) CONSTRUCTOR
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) CONSTRUCTOR
FUNC_NAME,aeobject **) CONSTRUCTOR
FUNC_NAME* {{{p	walk+_aget_m=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) DESTRUCTOR
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) DESTRUCTOR
FUNC_NAME,aeobject **) DESTRUCTOR
FUNC_NAME* {{{r	walk+_adet_m=bregpSUCCESS;se 

eBJ_Hinr;

_STSUCCESS;-> FA= vae	a{earp =name(st chast chttic namDe	/* get_m%s::ce T canom/ltaknd_va **) s", scoas->S) {, ptl->fpara)re
e'r}e 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) CLONE
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) CLONE
FUNC_NAME,aeobject **) CLONE
FUNC_NAME* {{{r	walk+_aglonem=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) CALL
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) CALL
FUNC_NAME,aeobject **) CALL
FUNC_NAME* {{{p	walk+		_

ael =bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) CALL	bATIC_FUNC_NAME*-1 g);
!bjecmpeloweEcaae_S) {,e **) CALL	bATIC_FUNC_NAME,aeobject **) CALL	bATIC_FUNC_NAME* {{{p	walk+		_

aelzend_ge	bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) TO	break_FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) TO	break_FUNC_NAME,aeobject **) TO	break_FUNC_NAME* {{{p	walk+		_
toase ISe	bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) GET
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) GET
FUNC_NAME,aeobject **) GET
FUNC_NAME* {{{p	walk+		_
 (Zm=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) SET
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) SET
FUNC_NAME,aeobject **) SET
FUNC_NAME* {{{p	walk+		_
s(Zm=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) UNSET
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) UNSET
FUNC_NAME,aeobject **) UNSET
FUNC_NAME* {{{p	walk+		_
uns(Zm=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) ISSET
FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) ISSET
FUNC_NAME,aeobject **) ISSET
FUNC_NAME* {{{p	walk+		_
iss(Zm=bregpSUCCESS;se 

}NOT_RE+;
	(f ame||
	 ;=aeobject **) DEBUGINFO_FUNC_NAME*-{rg);
!bjecmpeloweEcaae_S) {,e **) DEBUGINFO_FUNC_NAME,aeobject **) DEBUGINFO_FUNC_NAME* {{{p	walk+		_
debugInfo = regpSUCCESS;se 

}NOT_RE{)-=errggTSUCCESS;
 *j->fre
e'ree_++;
	regpSUCCESS;

	*p =	umentck;

_mag_g_bj getoimple**) aLL;
(scoas}}regpSUCCESS;,ast chttic int parsject)-=eree_ree_ptlwalk   tid walk  strp Z_STRloweEcaae_S) {pac	}d_BJ_Hunload

	rg_obeforeeunload ISILdisplay  el remd n ISebadeSUCCESS;
in     moduISiariabif (scoas	a{earp Z_STR)nd_w*)lc	objectS) {)re
e}			 = *speptl->fpara)heck__f ame||
	 ;
str|
	eptl->fpara)re
eeloweEcaae_S) {r Ival_ps;

	oloweEN_upeptl->fpara,ef ame||
	);

			breval_phash
exis;s(t_vaet_SUCCESS;tterou, loweEcaae_S) {,ef ame||
	+1	yp	*p =	umentst chast chttic namFUCCESS;
regis;
aESS;
Sa *sd {{duplicuesiS) {e- %s%s%s", scoase? scoas->S) { : "",	scoase? "::" : "",	ptl->fpara)re
e'}e

p Z_STR)nd_w*)loweEcaae_S) {pac			ptlwalk  }
'rva, denregis;CT , "Wronge(, "Wronge,bZVAL(P(t_vaet_SUCCESS;tterourobj->object)-=rg_count = (int)(});
			scoas	a{earscoas->cnst * get_ =m_tmp;earscoas->det * get_ =mdtmp;earscoas->glonem=bglone;earscoas->_

ael =b_

ael;earscoas->_

aelzend_ge	b_

aelzend_g;earscoas->_
toase ISe	b_
toase IS;earscoas->_
 (Zm=b_
 (Z;earscoas->_
s(Zm=b_
s(Z;earscoas->_
uns(Zm=b_
uns(Z;earscoas->_
iss(Zm=b_
iss(Z;earscoas->_
debugInfo = _
debugInfore

turn_tmp)rrse___tmp->common.,n_mentin|=_ucharACC_CTOR;

			bre_tmp->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namCnst * get_ %s::ce T canom/lbetzend_g", scoas->S) {, _tmp->common., "Wrong para)se e'}e

p_tmp->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	dtmp)rrse__dtmp->common.,n_mentin|=_ucharACC_DTOR;

			bredtmp->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namDe	/* get_m%s::ce T canom/lbetzend_g", scoas->S) {, dtmp->common., "Wrong para)se e'}e

pdtmp->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	glone)rrse___lone->common.,n_mentin|=_ucharACC_CLONE;

			bre_lone->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namCnst * get_ %s::ce T canom/lbetzend_g", scoas->S) {, _lone->common., "Wrong para)se e'}e

p_lone->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_

ael)heck_
BJ_H_

ael->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _

ael->common., "Wrong para)se e'}e

p_

ael->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_

aelzend_g)heck_
BJ_H!n_

aelzend_g->common.,n_mentin&_ucharACC_	bATICyyp	*p =	umentst chast chttic namMj getm%s::ce T mu zebndzend_g", scoas->S) {, _

aelzend_g->common., "Wrong para)se e'}e

p_

aelzend_g->common.,n_mentin|=_ucharACC_	bATIC;
 <rek++;
	_
toase IS)heck_
BJ_H_
toase IS->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _
toase IS->common., "Wrong para)se e'}e

p_
toase IS->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_
 (Z)heck_
BJ_H_
 (Z->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _
 (Z->common., "Wrong para)se e'}e

p_
 (Z->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_
s(Z)heck_
BJ_H_
s(Z->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _
s(Z->common., "Wrong para)se e'}e

p_
s(Z->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_
uns(Z)heck_
BJ_H_
uns(Z->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _
uns(Z->common., "Wrong para)se e'}e

p_
uns(Z->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_
iss(Z)heck_
BJ_H_
iss(Z->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _
iss(Z->common., "Wrong para)se e'}e

p_
iss(Z->common.,n_mentin&= ~ucharACC_ALLOW_	bATIC;
 <rek++;
	_
debugInfo)heck_
BJ_H_
debugInfo->common.,n_mentin&_ucharACC_	bATICyp	*p =	umentst chast chttic namMj getm%s::ce T canom/lbetzend_g", scoas->S) {, _
debugInfo->common., "Wrong para)se e'}e

}
rp Z_STR)nd_w*)lc	objectS) {)re
} '**)(p-arg_count);

		*(argume
		_tid =-1 meansastSOUR el , "Wronge, o   rwise,
 *astSOURt   mirsre_tid  , "Wronge
nction_name(Tl(argumentenregis;CT , "Wronge(onst cunt--SUCCESS;t, class, "Wronge,b
	re_tid ,b statics/g>SUCCESS;tterouint parse_arg_object_to_shnst cunt--SUCCESS;t, class_str= , "Wrongese PIr}i=0_m) statics/g>t_vaet_SUCCESS;tterour= , "Wrongtterouse	}
			!t_vaet_SUCCESS;tterou	walk+t_vaet_SUCCESS;tterour= CG(SUCCESS;tterou	re
} = = *speptl->fpara)heck_Pbre_tid !=-1 && i>=ZVAL(ncount		case I_R}0#+;
0
::	{
		eat'tf(-Unregis;CT ISece T\n", ptl->fpara)re#Oinclu	- {
		hash
del(t_vaet_SUCCESS;tterou, ptl->fpara,estr|
	eptl->fpara)+1)se eptlwalk  iwalk ==>name;
		*claon_name(Trg_cname(s		rtup_moduISNnmentmoduIS_L classmoduISarg_object_to_snt parsFETCH();
);
			(moduISi *,mentregis;CT PIr;

_STmoduISNmoduISint pars*sp)n! =j->fe);
,ments		rtup_moduIS_LONmoduISint pars*spe 					if (parse_name = ***);
		*-ss_rg_count = (int)>name;
		*claon_name(Trg_cname(aet_moduIS_s		rted(hNG zend_wromoduIS_nara)hg_object_to_sunt--moduIS_L classmoduISres_rg_couneval_phash
find(&moduIS_regis;
y, moduIS_nara,
str|
	emoduIS_para)+1IL(s_ar**)&moduISpe 					if ( );
moduIS->moduIS_s		rtedpa?				if ( :nt = (int)>name;
		*clazend_ge
	re_eean-moduIS_objec(onst c	{
		object, classs_n}}
	re*moduIS_nuect)robj->obe_arg_object_to_st;
	(p_n)->	case = on_naINTERNE:
CLASSr); (p_n)->info.PIr;

_S.moduIS->moduIS_nuect)r =e*moduIS_nuect)parse_name = on_naHASHamePLY_REMOVE;e }NOT_REF(arname = on_naHASHamePLY_KEEPlk ==>name;
		*clazend_gel(arg_eean-moduIS_objecesHinr moduIS_nuect)robj->obe_arg_object_to_s {
		hash
apply_bjec__va **) (EG(_bjectterou), (apply_SUCC= va
(nc_eean-moduIS_objec, (s_arra) &moduIS_nuect)robj->object)>name;
		*clas_arrmoduIS_det * get_NnmentmoduIS_L classmoduISarg_object_to_snt parsFETCH();
);
			moduIS->	case   MODULE_TEMPORARY	walk+name(_eean-moduIS_rsrc_dtmps(moduIS->moduIS_nuect)robj->objeclk   eean-moduIS_onst ants(moduIS->moduIS_nuect)robj->objeclk   eean-moduIS_objecesHmoduIS->moduIS_nuect)robj->objeclk }	d_BJ_HmoduIS->moduIS_s		rted );
moduIS->moduIS_shutdown_, "W)rrs#+;
0
::	{
		eat'tf(-%s: ModuISishutdown\n", moduIS->S) {)re#Oinclu	-moduIS->moduIS_shutdown_, "W	moduIS->tic (*moduIS->moduIS_nuect)robj->objec;ek}m c			Deictsilaise moduISiglobalserg);
			moduIS->globals_eobjo		*#+;stanoTS)-=
			*moduIS->globals_id__stncount	ts*Z_STTid	*moduIS->globals_id__stnt)-=}0#OT_R
 <
			moduIS->globals_dtmp)rrse__moduIS->globals_dtmp	moduIS->globals__strobj->object)-=}0#Oinclu	}ds_moduIS->moduIS_s		rted=0_m)
			moduIS->, "Wronge	walk+name(enregis;CT , "Wronge(moduIS->, "Wronge,b-_zvj->feobj->objec;ek}m #+;
HAVE_LIBDL #+;
!(stained(NETWA_P	a);
stained(APACHE_1_BUILD))m)
			moduIS-> no reg);
!aetenv(" **) DONT_UNLOAD_MODULES"yyp	*p DL_UNLOAD	moduIS-> no rec;ek}m#Oinclu#Oincluparam = (zval **) p-(al(argumentRMLS_uestmoduISdmeter coDarg_object_to_sunt--moduIS_L class*p  *moduIS_ntryesc_s		rtup_ no read				 = *spe*p	walk+name(moduIS_L classmoduISi;
pp;
lk++;
	moduIS->ntryesc_s		rtup_, "W	moduIS->tic (*moduIS->moduIS_nuect)robj->objec==TRVAL_Po		*p =name(st char *class_namntryesc_s		rtup T ,t_m%s moduISiSa *sd", moduIS->S) {ct)-=eexit(1)re
e}			pwalk ==>name;
		*cla
		_ el reryescaghutdown ft_ all moduISserg)inr moduIS_regis;
yy t(inupNnmentmoduIS_L classmoduISint parse_arg_object_to_st;
	moduIS->ntryesc_shutdown_, "W)rrs#+;
0
::	{
		eat'tf(-%s: Reryescaghutdown\n", moduIS->S) {)re#Oinclu	-moduIS->ntryesc_shutdown_, "W	moduIS->tic (*moduIS->moduIS_nuect)robj->objec;ek}mrname = 0	*param = (zval **) p-(al(argumentobRMLS_uestmoduISdmeter coDarg_object_to_sEG(opline__stnc *j->frrg_oJe're nov
	swer executce, anythce, zval+umentclaseck_PbreEG(SUlltteroury t(inup)o		*p =name(hash
ntverse
apply(&moduIS_regis;
y, (apply_SUCC=DL moduIS_regis;
yy t(inuprobj->object)-=}NOT_RE{)-=eunt--moduIS_L class*p  *moduIS_ntryesc_shutdown_ no read);	}
	 = *spe*p	walk+k+name(moduIS_L classmoduISi;
pp;
lk+	-moduIS->ntryesc_shutdown_, "W	moduIS->tic (*moduIS->moduIS_nuect)robj->objec;ek			pwalk  f} zend_}gumentmentcla(pacparam = (zval **) p-(al(argumentct(inup_PIr;

_STobjecesHeter coDarg_object_to_sunt--object, classpp =|_entry t(inup_ no read				 = *spe*p	walk+name(ct(inup_PIr;

_STobjecaatore*probj->objec;ek	pwalk ==>name;
		*clainr moduIS_regis;
yyunload_temp(onst c	{
		moduIS_L classmoduISint parse_arg_object_to_srg_counemoduIS->	case   MODULE_TEMPORARY	w? on_naHASHamePLY_REMOVE :non_naHASHamePLY_STOPt)>name;
		*clazend_ge
	reexec_done_cbNnmentmoduIS_L classmoduISint parse_arg_object_to_st;
	moduIS->**moddeRMLS_uest, "W)rrse_moduIS->**moddeRMLS_uest, "W(c;ek}mrname = 0	*param = (zval **) p-(al(argument**moddeRMLS_uestmoduISdmeter coDarg_object_to_sPbreEG(SUlltteroury t(inup)o		*p  {
		hash
apply(&moduIS_regis;
y, (apply_SUCC=DLeexec_done_cbrobj->objec;ek	name(hash
ntverse
apply(&moduIS_regis;
y, (apply_SUCC=DL moduIS_regis;
yyunload_temprobj->objec;ek}NOT_RE{)-=unt--moduIS_L class*p  *moduIS_**moddeRMLS_uest no read					 = *spe*p	walk+kname(moduIS_L classmoduISi;
pp;
lk+	moduIS->**moddeRMLS_uest, "W(c;ek		pwalk  }e
});

		*(argume clreme =     aext Z_ST moduISinuect)rction_name(T		ca,mentval *Z_STTmoduISNs_ararg_object_to_slone TSname(hash
 FA=ele**) s(&moduIS_regis;
y)*+	1re>name;
		*clazend_geunt--object, classdotregis;CT PIr;

_STobjec(unt--object, classorig-object, cla, umentet_obce_mentinobj->obe_arg_object_to_s {
		object, class_bject, clas *m(zval eobject,mentobject, cla pac	_d_wroloweEcaae_S) {s *em(zval orig-object, cla->S) {_CE_P(o*+	1 _m)va, de	}

	hash;
	s_bject, clas *sorig-object, cla;s
r_bject, cla->	case  on_naINTERNE:
CLASS			name(PItsi			zeTobjecaatoreobject, cla, probj->object)-_bject, cla->ce_mentin=bce_mentit)-_bject, cla->info.PIr;

_S.moduISi *\
	ctor */amoduIS);
);
			_bject, cla->info.PIr;

_S.builtce_, "Wronge	walk+name(regis;CT , "Wronge(object, cla, _bject, cla->info.PIr;

_S.builtce_, "Wronge, &_bject, cla->SUCCESS;tterou, MODULE_PERSISTENTrobj->objec;ek}m cval_ps;

	oloweEN *ne(loweEcaae_S) {,eorig-object, cla->S) {, _bject, cla->S) {_CE_P(opac	loweEcaae_S) {s *)nd_w*)val_pvaw(PIr;

edm		returloweEcaae_S) {,eobject, cla->S) {_CE_P(o*+	1, 1robj->object)-hashn;
strphash(loweEcaae_S) {,e_bject, cla->S) {_CE_P(opac	val_phash
ryick
upatoe(CG(_bjectterou), loweEcaae_S) {,e_bject, cla->S) {_CE_P(o+1ILhash, &object, cla, eobject,mentobject, cla *)zvj->f)re
g	rp Z_STRloweEcaae_S) {pac	lone TSobject, cla;s;

		*(argume clIf get_*/ace o vno/lj->fe   neitiinherits Z_om get_*/ace
 clIf get_*/ace o vj->feno  get_*/aS) {eo  }}}   neitilooks ,t_m    get_*/eno  inherits Z_om it
 clIf bo(o*get_*/ace no  get_*/aS) {eet_ij->feitidoe va
regul_wr	bjec regis;
aESS;
 clIf get_*/aS) {eo vspecified butvno/lfouo  j->feislreme =ed
nction_name(T,mentobject, cla *,mentregis;CT PIr;

_STobject,x( {
		object, class_bject, cla,T,mentobject, cla *get_*/ace,end_wroget_*/aS) {eobj->obe_arg_object_to_s {
		object, classregis;CT objecse	}
			!get_*/ace && get_*/aS) {	walk+name(ctject, classpp_nprv		breval_phash
find(CG(_bjectterou), get_*/aS) {,estr|
	epet_*/aS) {	+1IL(s_arraa) &pcSc==TRVAL_Po		*p =name = j->fre
e}NOT_RE{)-=eget_*/ace ;
pp_nprv }e };	}regis;CT objeci *,mentregis;CT PIr;

_STobjec(otject, clasobj->object)	}
			get_*/ace	walk+name(dotinheritance(regis;CT objec,*get_*/ace obj->objec;ek}mrname = regis;CT objecseparam = (zval **) p-(al(argumentctjectimple**) s( {
		object, class_bject, claeobj->obe_}}
	re FA=pe) rfacec,*...arg_object_to_s {
		object, classpe) rfacet, cla;s	va_lis; pe) rface_lis;;s	va_s		rt(pe) rface_lis;,e FA=pe) rfacec)				 = *spe FA=pe) rfacec--)heck_PIr;
facet, clai *va_arg(pe) rface_lis;,e,mentobject, cla *);lk+name(dotimple**) =pe) rface(object, cla, PIr;
facet, claiobj->objec;ek}m cva_ame(pe) rface_lis;);s;

		*(argume clA
_bjec   at P nid n vatIleast
onemabstra zemj getmautomnd_g(zvy to omec   	abstra ze	zend.
nction_name(T,mentobject, cla *,mentregis;CT PIr;

_STobjec(unt--object, classorig-object, claint parse_arg_object_to_srg_coundotregis;CT PIr;

_STobjec(orig-object, cla, 0int pars*spacparam = (zval **) p-(a,mentobject, cla *,mentregis;CT PIr;

_STpe) rface(unt--object, classorig-object, claint parse_arg_object_to_srg_coundotregis;CT PIr;

_STobjec(orig-object, cla, ucharACC_INTERFACEint pars*spacparam = (zval **) p-(a		ca,mentregis;CT object			act,x(hNG zend_wroS) {,et't  ame||
	,c	{
		object, class_nint parse_arg_object_to_shar **lcS) {e Ival_ps;

	oloweEN_upeS) {,  ame||
	*); PIr}r(Z;e	}
			lcS) {[0]e   '\\'parse_name Ival_phash
add(CG(_bjectterou), lcS) {+1IL ame||
	,c&ce, eobject,mentobject, cla *)zvj->f)re
}NOT_REF(arname Ival_phash
add(CG(_bjectterou), lcS) {,  ame||
	+1IL&ce, eobject,mentobject, cla *)zvj->f)re
}
 = Z_STRlcS) {ct)-+;
	rete 					if (parse_cS->ntf tid walk }mrname = ret	*param = (zval **) p-(arg_cname(set-hash
symbolNn "unksymbol, ING zend_wroS) {,et't  ame||
	P(o,c	{
		booleis_		f}}
	re FA=symboltterour,*...arg_object_to_s statics/g>symboltterou;s	va_lis; symboltterou_lis;;sl++;
	 FA=symboltterour <=			wrg_count = (int)
	Z SET
ISREF_TO_P(symbol, is_		f)				va_s		rt(symboltterou_lis;,e FA=symboltterourct)- = *spe FA=symboltterour--r>			walk+symboltteroui *va_arg(symboltterou_lis;,e statics/g>c;ek	name(hash
upatoe(symboltterou,  ame, S) {_CE_P(o*+	1, &symbol, eobject, "unk)zvj->f)re
	, "u
add_		f(&symbolc;ek}mrva_ame(symboltterou_lis;ct)-name = ***);
		*param = (zval			Diseroude, "Wronge support(zval			bjechastoal(argdisplay_diseroud_, "WrongNs_ara
DummyeSUCCESS;
 = chgdisplayc   	st ch
 = nea diseroude, "Wrongeislg(zved.nction_name(Ton_naFUNCTION(display_diseroud_, "Wrong)to_s {
		st char *class_namce T has to nediseroude,ch
sectoity			asnge", aet_RMLS_e_, "Wrong parameter coC)pacparam = (zval **) p-(a		ca,mentdiserou_, "WrongNnd_wro, "Wrong para, et_ob, "Wrong para_CE_P(o*obj->obe_arg_object_to_s {
		PIr;

_STSUCCESS;
*SUCC;
		breval_phash
find(CG(SUCCESS;tterou	, , "Wrong para, , "Wrong para_CE_P(o+1IL(s_arraa)&SUCCc==			if (parse_SUCC-> va
info = j->fre
eSUCC-> no reae		on_naFN(display_diseroud_, "Wrong);se_name = ***);
		*-ss_rg_count = (int)>name;
		*cla#+;stanon_naWIN32
#pragma optimobj("",	off)e#Oincluzend_geunt--objct - "uuegdisplay_diseroud_objec(unt--object, class_bjecttic int parse_arg_object_to_sunt--objct - "uuegrg_ "u;_sunt--objct 
*PIr;

t)-nam "un=eunt--objct spvaw(&PIr;

,e_bjecttic int parsject)- {
		st char *class_namce T has to nediseroude,ch
sectoity			asnge", _bjecttic ->S) {ct)-name = ret "u;_}a#+;stanon_naWIN32
#pragma optimobj("",	on)e#Oincluame;
		*clazend_gehnst cunt--SUCCESS;t, clasdiseroud_objecpvaw[] ;
o_son_naFE_n_n
};al **) p-(a		ca,mentdiserou_objec(od_wroobjectS) {,eu
	re_entry ame||
	P(o*obj->obe_arg_object_to_s {
		ctject, classpdiseroud_objec;m cval_ps;

	oloweE(objectS) {,e_entry ame||
	P(opac		breval_phash
find(CG(_bjectterou), objectS) {,e_entry ame||
	P(o+1IL(s_arraa)&diseroud_objecc==TRVAL_Po		*p rg_count = (int)(});INIT_CLASS_n_TRY_INIT_METHODS((spdiseroud_objec),sdiseroud_objecpvaw,bj->fP(j->fP(j->fP(j->fP(j->fpac	(pdiseroud_objec)->c		ate-objct 
=gdisplay_diseroud_objecac	val_phash
 t(in(&((pdiseroud_objec)->SUCCESS;tterou	ct)-name = ***);
		*param = (zvalzend_ge
	re {
		Ps

aelerou_ok;

_objec(onst cnd_wroS) {,et't  ame||
	,c	{
		f
ael
info

aok;
*Scc}}
	re*		ret -objec,*nd_wro*st ch
nt parse_arg_object_to_st't name I0_m)va, dobject, classpp_nprvhar **lcS) {e Ival_ps;

	oloweEN_upeS) {,  ame||
	*);
	*		ret -objec**p0_m) ;
	 ame||
	 ;=aeobject"self"* {{{ );e
   |!bjecmpelcS) {, "self",aeobject"self"* {{{p	walk++;
	!EG	scoas	)heck_
BJ_Hst ch) *st ch
= et *_upe"canom/lacceec*self::
 = neno
_bjec scoaseo vaMLS_e"ct)-=}NOT_RE{)-=eScc->c(zved_scoase		\
	c(zved_scoasc;ek		Scc->c(zving_scoase		\
	scoasc;ek		+;
	!Scc->objct -_stncount		Scc->objct -_ste		\
	Turn)se e'}e

pname I1re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject"get_*/"* {{{ ); (aa
   | |!bjecmpelcS) {, "get_*/",aeobject"get_*/"* {{{p	walk++;
	!EG	scoas	)heck_
BJ_Hst ch) *st ch
= et *_upe"canom/lacceec*get_*/::
 = neno
_bjec scoaseo vaMLS_e"ct)-=}NOT_RE+;
	!EG	scoas	->get_*/)heck_
BJ_Hst ch) *st ch
= et *_upe"canom/lacceec*get_*/::
 = nector */
_bjec scoasehas no
get_*/"*t)-=}NOT_RE{)-=eScc->c(zved_scoase		\
	c(zved_scoasc;ek		Scc->c(zving_scoase		\
	scoasc->get_*/;ek		+;
	!Scc->objct -_stncount		Scc->objct -_ste		\
	Turn)se e'}e

p*		ret -objec**pe_storname I1re

}y:}NOT_RE+;
	 ame||
	 ;=aeobject"zend_g"* {{{ );e
   |
   | |!bjecmpelcS) {, "zend_g", sobject"zend_g"* {{{p	walk++;
	!EG	c(zved_scoasc)heck_
BJ_Hst ch) *st ch
= et *_upe"canom/lacceec*send_g::
 = neno
_bjec scoaseo vaMLS_e"ct)-=}NOT_RE{)-=eScc->c(zved_scoase		\
	c(zved_scoasc;ek		Scc->c(zving_scoase		\
	c(zved_scoasc;ek		+;
	!Scc->objct -_stncount		Scc->objct -_ste		\
	Turn)se e'}e

p*		ret -objec**pe_storname I1re

}y:}NOT_RE+;
	val_plookup_vbject,x(S) {,  ame||
	P(j->fP(1, &pcSint pars*spe 					if (parse_	{
		object, classscoase		\
	RMLS_e_op_array	w? \
	RMLS_e_op_array	->scoase:
j->frect	Scc->c(zving_scoase		pp_nprv		brescoasg);
!Scc->objct -_stg);
\
	Turn)r);_st   |ist ancjec_, "WrongNZ_OBJCE_P(\
	Turn)),	scoasent pars*spe);_st   |ist ancjec_, "WrongNscoas}}Scc->c(zving_scoasent pars*sp)n{)-=eScc->objct -_ste		\
	Turn)se e'Scc->c(zved_scoase		Z_OBJCE_P(Scc->objct -_stnt)-=}NOT_RE{)-=eScc->c(zved_scoase		Scc->objct -_ste?	Z_OBJCE_P(Scc->objct -_stne:
Scc->c(zving_scoasre
e}			*		ret -objec**pe_stoname I1re
}NOT_RE{)-=BJ_Hst ch) val_pspeat'tf(st ch, 0, "objec*'%.*s'vno/lfouo ",  ame||
	P(S) {)re
} ' Z_STRlcS) {ct)-name = ret	*param = (zvalzend_ge
	re {
		Ps

aelerou_ok;

_, "W(
	re_k;

_,enti,c	 "unk
aelerou,c	{
		f
ael
info

aok;
*Scc}}
	re		ret -objec,*nd_wro*st ch
nt parse_arg_object_to_s	{
		object, class_n_orge		Scc->c(zving_scoasre
t't nam "un=e0prvhar **mS) {, *lmpara;ckonst cnd_wrocolo;se 
	re_|
	P(m|
	PP(	{
		object, classbjet_scoasre
 statics/g>Sterouse 
	re
ael
via_ no reae		0;sl++;
	st ch) {)-=*st ch
= j->fre
} * Scc->c(zving_scoase		j->fre
Scc->SUCCESS;t no reae		j->frect+;
	!_n_org) {)-= clSkipIlead IS \iariabif (Z_STRVAL_P(
aelerou)[0]e   '\\'parse_	m|
	 ;
Z_STRLEN_P(
aelerou) {{{re
eelmS) {e Ival_ps;

	oloweEN_upeZ_STRVAL_P(
aelerou)*+	1, m|
	pre

}NOT_REF(argm|
	 ;
Z_STRLEN_P(
aelerou)re
eelmS) {e Ival_ps;

	oloweEN_upeZ_STRVAL_P(
aelerou), m|
	pre

})-= clCk;

 if SUCCESS;
 i(o*gS_e;
S) {eexis;s.lk+ clTurn maylbnda compouo  S) {e  at includes S) {spaceeS) {eariabif (val_phash
find(EG(SUCCESS;tterou	, lmS) {, m|
	+1IL(s_araa)&Scc->SUCCESS;t no reape 					if (parse_' Z_STRlmS) {ct)-=ename = 1re

}y:' Z_STRlmS) {ct)-}m c			Split
S) {eonto
_bjec/S) {spaceeno  mj get/SUCCESS;
S) {serg);
			(colo;e IumentmemrchreZ_STRVAL_P(
aelerou), ':',
Z_STRLEN_P(
aelerou)p)n! =j->fe);k   tlo;e> Z_STRVAL_P(
aelerou)*);k  *(colo;-{rg   ':'
		walk+colo;--lk   ee;e I tlo;e- Z_STRVAL_P(
aelerou)lk  m|
	 ;
Z_STRLEN_P(
aelerou) {{ ee;e- 2;
lk++;
	colo;e = Z_STRVAL_P(
aelerou))heck_
BJ_Hst ch) val_pspeat'tf(st ch, 0, "invalidlSUCCESS;
S) {"ct)-=ename = 0 I_R}0 TS clTurn o va
_ompouo  S) {.lk+ clTlasto
fetch
_bjec no     nefind*send_g mj get. ariabbjet_scoase		\
	scoasc;ek	+;
	cn_org) {)-=	\
	scoascn=bce_org;ee_}ce;kBJ_H! {
		Ps

aelerou_ok;

_objec(Z_STRVAL_P(
aelerou), _|
	P(Scc}}&		ret -objec,*st ch
nt pars*sp)n{)-=e\
	scoascn=bbjet_scoasre
=ename = 0 I_R}0=e\
	scoascn=bbjet_scoasrect	Steroui *&Scc->c(zving_scoas->SUCCESS;tterou;ek	+;
	cn_orgg);
!ist ancjec_, "WrongNcn_org}}Scc->c(zving_scoasent pars*sp)n{)-=eBJ_Hst ch) val_pspeat'tf(st ch, 0, "objec*'%s'vo vno/la subobjec*of*'%s'", ce_org->S) {, Scc->c(zving_scoas->S) {ct)-=ename = 0 I_R}0=emS) {e IZ_STRVAL_P(
aelerou)*+	c|
	 +	2xy:}NOT_RE+;
	_n_org) {)-= clTlasto
fetch
find*send_g mj get*of*gS_e;
	zend. ariabm|
	 ;
Z_STRLEN_P(
aelerou)re
emS) {e IZ_STRVAL_P(
aelerou);ct	Steroui *&ce_org->SUCCESS;tterou;ek	Scc->c(zving_scoase		ce_org;ee}NOT_REF(ar clWe alreadylck;

he ,ch
pld noSUCCESS;
before.eariabif (st ch
);
!(_k;

_,enti & IS CALLABLE_CHECK_SILENT		walk+kname(speat'tf(st ch, 0, "SUCCESS;
'%s'vno/lfouo  ch
invalidlSUCCESS;
S) {", Z_STRVAL_P(
aelerou)) I_R}0=ename = 0 I_}ce;lmS) {e Ival_ps;

	oloweEN_upemS) {, m|
	pac		bre		ret -objec*);e
   |Scc->c(zving_scoase);e
   |m|
	 ;=aeobject **) CONSTRUCTOR
FUNC_NAME*-{ );e
   |!bjecmpelmS) {,e **) CONSTRUCTOR
FUNC_NAME,aeobject **) CONSTRUCTOR
FUNC_NAME* {{{p	walk+Scc->SUCCESS;t no reae		Scc->c(zving_scoas->cnst * get_;ek	+;
	Scc->SUCCESS;t no reape	*p =nam "un=e1re

}y:}NOT_RE+;
	val_phash
find(fterou, lmS) {, m|
	+1IL(s_araa)&Scc->SUCCESS;t no reape 					if (parse_nam "un=e1re

+;
	(fcc->SUCCESS;t no rea->op_array.,n_mentin&_ucharACC_CHANGEDpe);_st   |!		ret -objec*);	\
	scoasce);_st   |ist ancjec_, "WrongNfcc->SUCCESS;t no rea->common.scoas}}\
	scoascent pars*sp)n{)-=eval_pSUCCESS;
*prS__fbc;
lk+	+;
	val_phash
find(&\
	scoasc->SUCCESS;tterou, lmS) {, m|
	+1IL(s_arraa) &prS__fbcc==			if (unt		&& grS__fbc->common.,n_mentin&_ucharACC_PRIVATEunt		&& grS__fbc->common.scoase			\
	scoascncount		Scc->SUCCESS;t no reae		prS__fbc;
 e'}e

}
rp
			(ck;

_,enti & IS CALLABLE_CHECK_NOrACCf (pa			0e);_st   |(Scc->c(zving_scoase);e

   |
((Scc->objct -_stg);
Scc->c(zving_scoas->_

ael)h||ck_   | |(!Scc->objct -_stg);
Scc->c(zving_scoas->_

aelzend_g))p)n{)-=eBJ_Hfcc->SUCCESS;t no rea->op_array.,n_mentin&_ucharACC_PRIVATEcheck_
aif (!umentck;

_prS_uesHfcc->SUCCESS;t no rea,	Scc->objct -_ste?	Z_OBJCE_P(Scc->objct -_stne:
\
	scoasc, lmS) {, m|
	ent pars*sp)n{)-=ee_nam "un=e0							Scc->SUCCESS;t no reae		j->fre					gstoaaet_SUCCESS;tvia_ no reare
e'r}e 

}NOT_RE+;
	fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_PROTECTEDpeeck_
aif (!umentck;

_prstd_tedNfcc->SUCCESS;t no rea->common.scoas}}\
	scoascp)n{)-=ee_nam "un=e0							Scc->SUCCESS;t no reae		j->fre					gstoaaet_SUCCESS;tvia_ no reare
e'r}e 

}e

}y:}NOT_RE{
aet_SUCCESS;tvia_ no rea:ek	+;
	Scc->objct -_stg);
Scc->c(zving_scoas ;=a_n_org) {)-=		bre		ret -objec*); ce_org->_

ael)heck_
	Scc->SUCCESS;t no reae		em(zval eobject,mentPIr;

_STSUCCESS;)c;ek			fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;.	case  on_naINTERNE:
FUNCTION; =			fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;.moduISi *(ce_org->	case = on_naINTERNE:
CLASS	w? ce_org->info.PIr;

_S.moduISi:	j->fre				fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;. no reae		val_ps;d

ael_usCT oael;ear		fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;. va
info = j->fre
e'	fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;. FA= vae  =0re
e'	fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;.scoase		ce_org;eee'	fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;.,n_mentin =ucharACC_CALL
VIA_HANDLER;eee'	fcc->SUCCESS;t no rea->PIr;

_STSUCCESS;., "Wrong para
 *et *n_upemS) {, m|
	pac	

p_ael
via_ no reae		1t)-=errg_ "un=e1re


}NOT_RE+;
	Z_OBJ_HT_P(Scc->objct -_stn->aet_mj get)heck_
	Scc->SUCCESS;t no reae		Z_OBJ_HT_P(Scc->objct -_stn->aet_mj get(&Scc->objct -_st, mS) {, m|
	zvj->feobj->objec;ek	k	+;
	Scc->SUCCESS;t no reape	*p =			bre		ret -objec*);e
nt
a   |(!Scc->SUCCESS;t no rea->common.scoase||ck_
a_   | !ist ancjec_, "WrongNcn_org}}Scc->SUCCESS;t no rea->common.scoasent pars*sp)pe	*p =		
+;
	(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_CALL
VIA_HANDLER) !=			walk+		-=eBJ_Hfcc->SUCCESS;t no rea->	case! =ucharOVERLOADEnaFUNCTION	walk+		-=ep Z_STR)nd_w*)fcc->SUCCESS;t no rea->common., "Wrong para)se e'
e'r}e
e'r=ep Z_STRScc->SUCCESS;t no reapse e'
e'}e
e'r=}NOT_RE{)-=ererrg_ "un=e1re




p_ael
via_ no reae		(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_CALL
VIA_HANDLER) !=		re




}e
e'r}e 

}e

}NOT_RE+;
	fcc->c(zving_scoas)n{)-=eBJ_Hfcc->c(zving_scoas->aet_zend_g_mj get)heck_
	Scc->SUCCESS;t no reae		fcc->c(zving_scoas->aet_zend_g_mj getHfcc->c(zving_scoas, mS) {, m|
	int parsject)-=erNOT_RE{)-=erScc->SUCCESS;t no reae		val_ps;d
aet_zend_g_mj getHfcc->c(zving_scoas, mS) {, m|
	zvj->feobj->objec;ek	k}
	k	+;
	Scc->SUCCESS;t no reape	*p =	rg_ "un=e1re



_ael
via_ no reae		(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_CALL
VIA_HANDLER) !=		re



+;
	_ael
via_ no reae);
!Scc->objct -_stg);
\
	Turn)r);_sta_   |Z_OBJ_HT_P(\
	Turn))->aet_object, clas);_sta_   |ist ancjec_, "WrongNZ_OBJCE_P(\
	Turn)),	Scc->c(zving_scoasent pars*sp)n{)-=e=eScc->objct -_ste		\
	Turn)se e'r}e 

}e

}y:}
)-+;
	ret "u	walk++;
	Scc->c(zving_scoase); !_ael
via_ no rea)heck_
BJ_H!Scc->objct -_stg);
(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_ABSTRACT)peeck_
aif (st ch) {)-=k+kname(speat'tf(st ch, 0, "canom/lPall abstra zemj getm%s::ce T", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para)se e'
enam "un=e0						}NOT_RE{)-=ere {
		st char ERRORnamCanom/lPall abstra zemj getm%s::ce T", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para)se e'
}e 

}NOT_RE+;
	!Scc->objct -_stg);
!(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_	bATICyyp	*p =	
	re	tverityre



_d_wroverb;ek	k	+;
	Scc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_ALLOW_	bATIC) {)-=k+k	tverityi= r 	breCTse e'
everbi= "shouldvno/"						}NOT_RE{)-=ere clAn  = N

_Se, "Wrong jecu {se$turn o vpres_*/eno  wo }}}ck;

	  at. So PHP wouldvcrashnby  elow IS     	 el. ariable=stverityi= r ERRORse e'
everbi= "canom/"re
e'red befP			(ck;

_,enti & IS CALLABLE_CHECK_IS 	bATIC) !=			walk+		-nam "un=e0						}d befP			\
	Turn)r);|ist ancjec_, "WrongNZ_OBJCE_P(\
	Turn)),	Scc->c(zving_scoasent pars*sp)n{)-=e=eScc->objct -_ste		\
	Turn)se e'raif (st ch) {)-=k+kkname(speat'tf(st ch, 0, "non-send_g mj get*%s::ce T %s	be c(zved*send_g(zvy, jecu  IS $turn Z_om _ompnd_ble}onstext %s", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para, verb, Z_OBJCE_P(\
	Turn))->S) {ct)-=e=			bre	tverityi== r ERROR	walk+		-=enam "un=e0							'}e
e'r=}NOT_RE+;
	ret "u	walk+=ere {
		st cha	tverity, "Non-send_g mj get*%s::ce T %s	be c(zved*send_g(zvy, jecu  IS $turn Z_om _ompnd_ble}onstext %s", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para, verb, Z_OBJCE_P(\
	Turn))->S) {ct)-=e=	}					}NOT_RE{)-=ereif (st ch) {)-=k+kkname(speat'tf(st ch, 0, "non-send_g mj get*%s::ce T %s	be c(zved*send_g(zvy", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para, verbct)-=e=			bre	tverityi== r ERROR	walk+		-=enam "un=e0							'}e
e'r=}NOT_RE+;
	ret "u	walk+=ere {
		st cha	tverity, "Non-send_g mj get*%s::ce T %s	be c(zved*send_g(zvy", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para, verbct)-=e=	}					}			cree_++;
	nam "un);
(ck;

_,enti & IS CALLABLE_CHECK_NOrACCf (pa			0peeck_
aif (fcc->SUCCESS;t no rea->op_array.,n_mentin&_ucharACC_PRIVATEcheck_
aaif (!umentck;

_prS_uesHfcc->SUCCESS;t no rea,	Scc->objct -_ste?	Z_OBJCE_P(Scc->objct -_stne:
\
	scoasc, lmS) {, m|
	ent pars*sp)n{)-=ee_eif (st ch) {)-=k+kk=
			*st ch) {)-=k+kk=p Z_STR*st ch)se e'
e'r}e
e'r=epname(speat'tf(st ch, 0, "canom/lacceec*grS_uesemj getm%s::ce T", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para)se e'
er}e
e'r=enam "un=e0							}					}NOT_RE+;
	(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_PROTECTEDpcheck_
aaif (!umentck;

_prstd_tedNfcc->SUCCESS;t no rea->common.scoas}}\
	scoascp)n{)-=ee_eif (st ch) {)-=k+kk=
			*st ch) {)-=k+kk=p Z_STR*st ch)se e'
e'r}e
e'r=epname(speat'tf(st ch, 0, "canom/lacceec*grstd_tedemj getm%s::ce T", Scc->c(zving_scoas->S) {}}Scc->SUCCESS;t no rea->common., "Wrong para)se e'
er}e
e'r=enam "un=e0							}					}e 

}e

}y:}NOT_REif (st ch
);
!(_k;

_,enti & IS CALLABLE_CHECK_SILENT		walk++;
	fcc->c(zving_scoas)n{)-=eBJ_Hst ch) val_pspeat'tf(st ch, 0, "objec*'%s'vdoe vom/lhavegaemj getm'%s'", Scc->c(zving_scoas->S) {}}mS) {ct)-=}NOT_REF(argPJ_Hst ch) val_pspeat'tf(st ch, 0, "SUCCESS;
'%s'vdoe vom/lexis;"}}mS) {ct)-=}e
} ' Z_STRlmS) {ct)
	+;
	Scc->objct -_st	walk+Scc->c(zved_scoase		Z_OBJCE_P(Scc->objct -_stnt)-})-+;
	ret "u	walk+Scc->PItsi			zede I1re
})-name = ret "u;_}aram = (zval **) p-(a,mentboole {
		Ps

aelerou_,x(  "unk
aelerou,c	 "unkobjct -_st, u
	re_k;

_,enti,cnd_wro*
aelerou_S) {,et't *
aelerou_S) {||
	,c	{
		f
ael
info

aok;
*Scc}}nd_wro*st ch
nt parse_arg_object_to_s	{
		booleret	* 
	re
aelerou_S) {||
	_loc"u;_sunt--f
ael
info

aok;
Scc_loc"u;_

+;
	_aelerou_S) {) {)-=*_aelerou_S) {
= j->fre
} 
+;
	_aelerou_S) {||
	 ;=aj->fpwalk+caelerou_S) {||
	 ; &
aelerou_S) {||
	_loc"u;_s}
	+;
	Scc ;=aj->fpwalk+Scc ;*&Scc_loc"u;_s}
	+;
	st ch) {)-=*st ch
= j->fre
} 	
+Scc->PItsi			zede I0;* Scc->c(zving_scoase		j->fre
Scc->c(zved_scoase		j->fre
Scc->SUCCESS;t no reae		j->fre Scc->c(zving_scoase		j->fre
Scc->objct -_ste		j->frect+;
	objct -_stg);
Zd_boolP(objct -_st	w!=	IS OBJECT) {)-=objct -_ste		j->fres}
	+;
	objct -_stg);
a   |(!EG(objct spstore).objct -bucketseStae
   |
!EG(objct spstore).objct -buckets[Z_OBJ_HANDLElP(objct -_st	].valid)o		*p rg_coun0 I_}ce;switch
(Zd_boolP(
aelerou))heck_caae IS 	break:(argPJ_Hobjct -_stncount		Scc->objct -_ste		objct -_st;eee'	fcc->c(zving_scoase		Z_OBJCE_P(objct -_stnt)-=	
+;
	_aelerou_S) {) {)-=


_d_wro_st;e)-=


*caelerou_S) {||
	 ; Scc->c(zving_scoas->S) {_CE_P(o*+	Z_STRLEN_P(
aelerou) + sobject"::") {{{re
ee eptle		p_aelerou_S) {
= em(zval *caelerou_S) {||
	 +	1 _m)k+	-memcpy(_st, Scc->c(zving_scoas->S) {}}Scc->c(zving_scoas->S) {_CE_P(o)re
ee eptle+; Scc->c(zving_scoas->S) {_CE_P(o_m)k+	-memcpy(_st, "::", sobject"::") {{{)re
ee eptle+; sobject"::") {{{re
ee ememcpy(_st, Z_STRVAL_P(
aelerou), Z_STRLEN_P(
aelerou) + 1)se e'
}e 

}NOT_RE+;
	_aelerou_S) {) {)-=

p_aelerou_S) {
= et *n_upeZ_STRVAL_P(
aelerou), Z_STRLEN_P(
aelerou))se e'
*caelerou_S) {||
	 ; Z_STRLEN_P(
aelerou)re
eeree_++;
	_k;

_,enti & IS CALLABLE_CHECK_SYNTAX_ONLYncount		Scc->c(zved_scoase		Scc->c(zving_scoasre
e=ename = 1re

_}ce;krname Ival_pPs

aelerou_ok;

_, "W(_k;

_,enti,cnaelerou,cScc}}0,*st ch
nt pars*sp;
	k	+;
	Scc ;=a&Scc_loc"us);_sta   |Scc->SUCCESS;t no reae);_sta_(Hfcc->SUCCESS;t no rea->	case=  on_naINTERNE:
FUNCTIONs);_sta   | 	(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_CALL
VIA_HANDLER))h||ck_a   | fcc->SUCCESS;t no rea->	case=  on_naOVERLOADEnaFUNCTION_TEMPORARYh||ck_a   | fcc->SUCCESS;t no rea->	case=  on_naOVERLOADEnaFUNCTION)peeck_
aif (fcc->SUCCESS;t no rea->	case! =ucharOVERLOADEnaFUNCTION	walk+		- Z_STR)nd_w*)fcc->SUCCESS;t no rea->common., "Wrong para)se e'
}					 Z_STRScc->SUCCESS;t no reapse e'})-=ename = r(Z;e	}_caae IS ARRAY:(argalk+k+n "unk*mj getm= j->fre
e'	n "unk*objm= j->fre
e'	
	re		ret -objece		0;sl+k+	+;
	val_phash
 FA=ele**) s(Z ARRVAL_P(
aelerou))h=  2) {)-=k+kname(hash
index
find(Z ARRVAL_P(
aelerou)}}0,*(s_arraa) &obj)re
ee ename(hash
index
find(Z ARRVAL_P(
aelerou)}}1IL(s_arraa) &mj get)						}d befP			objm);
mj getm);e
nt
a(Zd_boolPP(obj)h=  IS OBJECTe||ck_
a_Zd_boolPP(obj)h=  IS 	break)r);_sta__Zd_boolPP(mj get)h=  IS 	break)r{
ck_
aaif (Zd_boolPP(obj)h=  IS 	break)r{)-=ee_eif (_aelerou_S) {) {)-=




_d_wro_st;e)-=


'
*caelerou_S) {||
	 ; Z_STRLEN_PP(obj)h+ Z_STRLEN_PP(mj get)h+ sobject"::") {{{re
ee e eptle		p_aelerou_S) {
= em(zval *caelerou_S) {||
	 +	1 _m)k+	- ememcpy(_st, Z_STRVAL_PP(obj), Z_STRLEN_PP(obj))re
ee e eptle+; Z_STRLEN_PP(obj)_m)k+	- ememcpy(_st, "::", sobject"::") {{{)re
ee e eptle+; sobject"::") {{{re
ee e ememcpy(_st, Z_STRVAL_PP(mj get), Z_STRLEN_PP(mj get)h+ 1)se e'
er}e)-=ee_eif (_k;

_,enti & IS CALLABLE_CHECK_SYNTAX_ONLYncount		e=ename = 1re

_
er}e)-=ee_eif (! {
		Ps

aelerou_ok;

_objec(Z_STRVAL_PP(obj), Z_STRLEN_PP(obj)P(Scc}}&		ret -objec,*st ch
nt pars*sp)n{)-=e	-=ename = 0 I_R_
er}e)-=ee_}NOT_RE{)-=erer+;
	!EG	objct spstore).objct -bucketseStae
k_
a_   |!EG(objct spstore).objct -buckets[Z_OBJ_HANDLElPP(obj)].valid)n{)-=e	-=ename = 0 I_R_
er}e)-=ee_	fcc->c(zving_scoase		Z_OBJCE_PP(obj)_rg_oTBFixed:
 =at if it's overloaded? zval+-=e=eScc->objct -_ste		*obj;
)-=ee_eif (_aelerou_S) {) {)-=




_d_wro_st;e)-=


'
*caelerou_S) {||
	 ; Scc->c(zving_scoas->S) {_CE_P(o*+	Z_STRLEN_PP(mj get)h+ sobject"::") {{{re
ee e eptle		p_aelerou_S) {
= em(zval *caelerou_S) {||
	 +	1 _m)k+	- ememcpy(_st, Scc->c(zving_scoas->S) {}}Scc->c(zving_scoas->S) {_CE_P(o)re
ee e eptle+; Scc->c(zving_scoas->S) {_CE_P(o_m)k+	- ememcpy(_st, "::", sobject"::") {{{)re
ee e eptle+; sobject"::") {{{re
ee e ememcpy(_st, Z_STRVAL_PP(mj get), Z_STRLEN_PP(mj get)h+ 1)se e'
er}e)-=ee_eif (_k;

_,enti & IS CALLABLE_CHECK_SYNTAX_ONLYncount		e=eScc->c(zved_scoase		Scc->c(zving_scoasre
e=ee=ename = 1re

_
er}ee'
er}e)-=ee_name Ival_pPs

aelerou_ok;

_, "W(_k;

_,enti,c*mj getP(Scc}}		ret -objec,*st ch
nt pars*spse e'raif (Scc ;=a&Scc_loc"us);_stata   |Scc->SUCCESS;t no reae);_sta_a_(Hfcc->SUCCESS;t no rea->	case=  on_naINTERNE:
FUNCTIONs);_stata   | 	(fcc->SUCCESS;t no rea->common.,n_mentin&_ucharACC_CALL
VIA_HANDLER))h||ck_a_a   | fcc->SUCCESS;t no rea->	case=  on_naOVERLOADEnaFUNCTION_TEMPORARYh||ck_a_a   | fcc->SUCCESS;t no rea->	case=  on_naOVERLOADEnaFUNCTION)peeck_
a=eBJ_Hfcc->SUCCESS;t no rea->	case! =ucharOVERLOADEnaFUNCTION	walk+		-=e Z_STR)nd_w*)fcc->SUCCESS;t no rea->common., "Wrong para)se e'
e'}e
e'r=e Z_STRScc->SUCCESS;t no reapse e'
e}
=ee=ename = r(Z;e	}_		}NOT_RE{)-=ereif (val_phash
 FA=ele**) s(Z ARRVAL_P(
aelerou))h=  2) {)-=k+kr+;
	!objmSta(Zd_boolPP(obj)h!  IS 	breakg);
Zd_boolPP(obj)h!  IS OBJECT)) {)-=k+kk=
			st ch) val_pspeat'tf(st ch, 0, "Sirsrearray
mject)ro vno/la validlobjeceS) {
ch
objct ")se e'
e'}NOT_RE{)-=erer=
			st ch) val_pspeat'tf(st ch, 0, "secondearray
mject)ro vno/la validlmj get"pse e'
e'}e
e'r=}NOT_RE{)-=erer
			st ch) val_pspeat'tf(st ch, 0, "array
mu zehavegexactly two
mject)s"pse e'
e}
=ee=eif (_aelerou_S) {) {)-=



p_aelerou_S) {
= et *n_upe"Array", sobject"Array")-1)se e'
er*caelerou_S) {||
	 ; sobject"Array") {{{re
ee e}					}			cree_+name = 0 I	}_caae IS OBJECT:(argPJ_HZ_OBJ_HANDLER_P(
aelerou, aet_closursce); Z_OBJ_HANDLER_P(
aelerou, aet_closursc(
aelerou, &fcc->c(zving_scoas, &fcc->SUCCESS;t no rea,	&Scc->objct -_stint pars*spe 					if (parse_=eScc->c(zved_scoase		Scc->c(zving_scoasre
e=eif (_aelerou_S) {) {)-=


	{
		object, class_ni		Z_OBJCE_P(
aelerou)rrg_oTBFixed:
 =at if it's overloaded? zval+-=e=*caelerou_S) {||
	 ; cs->S) {_CE_P(o*+	sobject"::_
invoke") {{{re
ee ep_aelerou_S) {
= em(zval *caelerou_S) {||
	 +	1 _m)k+	-memcpy(*
aelerou_S) {,ecs->S) {, _s->S) {_CE_P(o)re
ee ememcpy((*
aelerou_S) {)*+	cs->S) {_CE_P(o, "::_
invoke",	sobject"::_
invoke"))						}-=k+kk=p	e
e=ename = 1re

_}cere cl	case miss IS  = NnESS;(zvy zval+-default:(argPJ_H_aelerou_S) {) {)-=

n "unexpEN *nere
e'	
	reuseN *nerelk+k+name(make	eat'terou_n "u(
aelerou, &expEN *ne, &useN *ne)se e'
*caelerou_S) {
= et *n_upeZ_STRVAL(expEN *ne), Z_STRLEN(expEN *ne))se e'
*caelerou_S) {||
	 ; Z_STRLEN(expEN *ne)re
e'	n "u_dtmp	&expEN *ne)re
e'}(argPJ_Hst ch) val_pspeat'tf(st ch, 0, "noearray
ch
s	retu*gS_e;"ct)-=ename = 0 I_}_}aram = (zval **) p-(a,mentboole {
		Ps

aelerou(  "unk
aelerou,cu
	re_k;

_,enti,cnd_wro*
aelerou_S) {int parse_arg_object_to_srg_coun {
		Ps

aelerou_,x(
aelerou,cj->fP(_k;

_,enti,cnaelerou_S) {,ej->fP(j->fP(j->fint pars*spacparam = (zval **) p-(a,mentboole {
		make	
aelerou(  "unk
aelerou,cnd_wro*
aelerou_S) {int parse_arg_object_to_sunt--f
ael
info

aok;
Sccrect+;
	 {
		Ps

aelerou_,x(
aelerou,cj->fP(IS CALLABLE_	breCT,cnaelerou_S) {,ej->fP(&Scc}}j->fint pars*sp	walk++;
	Zd_boolP(
aelerou)h=  IS 	breakg);
Scc.c(zving_scoas)n{)-=en "u_dtmp	
aelerou)re
eearray(PIts	
aelerou)re
eeadntval *index
		returnaelerou,cScc.c(zving_scoas->S) {}}1)re
eeadntval *index
		returnaelerou,cScc.SUCCESS;t no rea->common., "Wrong para, 1)re
e}			BJ_Hfcc.SUCCESS;t no reae);_sta((Scc.SUCCESS;t no rea->	case=  on_naINTERNE:
FUNCTIONs);_st   | 	(fcc.SUCCESS;t no rea->common.,n_mentin&_ucharACC_CALL
VIA_HANDLER))h||ck_   | fcc.SUCCESS;t no rea->	case=  on_naOVERLOADEnaFUNCTION_TEMPORARYh||ck_   | fcc.SUCCESS;t no rea->	case=  on_naOVERLOADEnaFUNCTIONp)n{)-=eBJ_Hfcc.SUCCESS;t no rea->	case! =ucharOVERLOADEnaFUNCTION	walk+		 Z_STR)nd_w*)fcc.SUCCESS;t no rea->common., "Wrong para)se e'}
r=e Z_STRScc.SUCCESS;t no reapse e}0=ename = 1;ek}mrname = 0	*param = (zval **) p-(a
	re {
		f
ael
info
PIts	  "unk
aelerou,cu
	re_k;

_,enti,c {
		f
ael
info
*Sci,c	{
		f
ael
info

aok;
*Scc}}nd_wro*
aelerou_S) {,ecd_wro*st ch
nt parse_arg_object_to_stf (! {
		Ps

aelerou_,x(
aelerou,cj->fP(_k;

_,enti,cnaelerou_S) {,ej->fP(Scc}}st ch
nt pars*sp)n{)-=rg_count = (int)(})e
Sci->sobj ; sobject*Sci);e
Sci->SUCCESS;tterour= ,cc->c(zving_scoase?*&Scc->c(zving_scoas->SUCCESS;tteroue:
\
	SUCCESS;tterou	re
Sci->objct -_ste		Scc->objct -_st;e
Sci->SUCCESS;tS) {
= naelerou;e
Sci->ret "u-_st-_ste		j->fresSci->param__tid   I0;* Sci->paramse		j->fresSci->no_separaESS;
 I1re
Sci->symboltteroui *j->frectname = ***);
		*param = (zval **) p-(al(argumentf
ael
info
 vae
 t(i_Nnmentf
ael
info
*Sci,ct_ob,_STTmemarg_object_to_stf (Sci->params	walk++;
	f_STTmemar{
r=e Z_STRSci->params	se e'Sci->paramse		j->fres=}e
} 'Sci->param__tid   I0;*param = (zval **) p-(al(argumentf
ael
info
 vae
saveNnmentf
ael
info
*Sci,ct_ob*param__tid ,c	 "unkkkkparams	wg_object_to_s*param__tid   ISci->param__tid ;_s*params  ISci->paramsresSci->param__tid   I0;* Sci->paramse		j->freparam = (zval **) p-(al(argumentf
ael
info
 vae
restoreNnmentf
ael
info
*Sci,ct_obparam__tid ,c	 "unkkkparams	wg_object_to_sumentf
ael
info
 vae
 t(i_NSci,c1)resSci->param__tid   Iparam__tid ;_sSci->paramse		paramsreparam = (zval **) p-(a
	re {
		f
ael
info
 vaeNnmentf
ael
info
*Sci,c	 "unk vae nt parse_arg_object_to_s staPosiESS;
pocac	v "unkkarg}}kkkparams;m cval_pf
ael
info
 vae
 t(i_NSci,c! vaect)
	+;
	! vaecarse_name = ***);
		*-ss
++;
	Zd_boolP( vaeca!  IS ARRAY)n{)-=rg_count = (int)(})e
Sci->param__tid   Ival_phash
 FA=ele**) s(Z ARRVAL_P( vaec);_sSci->paramse		paramse		(	 "unkkk)}ste(zval Sci->params,ISci->param__tid  * eobject, "unk*));m cval_phash
inr;

_STpoinr;

reset_,x(Z ARRVAL_P( vaec, &porct)- = *speval_phash
aet_ctor */aator_,x(Z ARRVAL_P( vaec, (s_arra) &arg}}&porce 					if (parse_kparams++e		arg;eeeval_phash
mo_e_,orward_,x(Z ARRVAL_P( vaec, &porct)-}ectname = ***);
		*param = (zval **) p-(a
	re {
		f
ael
info
 vapNnmentf
ael
info
*Scieobj->obe_}}
	re vac,c	 "unkkk vavarg_object_to_st't it)
	+;
	 vac <	0peeck_rg_count = (int)(})e
val_pf
ael
info
 vae
 t(i_NSci,c! vac)t)
	+;
	 vacpwalk+Sci->param__tid   I vac;
e'Sci->paramse		(	 "unkkk)}ste(zval Sci->params,ISci->param__tid  * eobject, "unk*));m c	,ch
(i  I0; i <	 vac; ++i)n{)-=eSci->params[i]  I vav[i]prv }e };	}reme = ***);
		*param = (zval **) p-(a
	re {
		f
ael
info
 vavNnmentf
ael
info
*Scieobj->obe_}}
	re vac,cva_lis; k vavarg_object_to_st't it)	v "unkkargt)
	+;
	 vac <	0peeck_rg_count = (int)(})e
val_pf
ael
info
 vae
 t(i_NSci,c! vac)t)
	+;
	 vacpwalk+Sci->param__tid   I vac;
e'Sci->paramse		(	 "unkkk)}ste(zval Sci->params,ISci->param__tid  * eobject, "unk*));m c	,ch
(i  I0; i <	 vac; ++i)n{)-=earge		va_arg(k vav,c	 "unkk	se e'Sci->params[i]  I vaprv }e };	}reme = ***);
		*param = (zval **) p-(a
	re {
		f
ael
info
 vanNnmentf
ael
info
*Scieobj->obe_}}
	re vac,c...arg_object_to_sPIr}r(Z;e	va_lis;  vav				va_s		rt( vav,c vac)t)_name Ival_pf
ael
info
 vavNScieobj->obCC,e vac,c& vava;mrva_ame( vava;mmrname = ret	*param = (zval **) p-(arg_cname(f
ael
info

all( {
		f
ael
info
*Sci,c	{
		f
ael
info

aok;
*Scc}}	 "unkkret "u-_st-_st,c	 "unk vae nt parse_arg_object_to_s	 "unkret "u}}kkkorg_paramse		j->fresPIr}r(sult,eorg__tid   I0;*e
Sci->ret "u-_st-_ste		ret "u-_st-_ste?	ret "u-_st-_ste: &rg_ "u;_s+;
	 vae	walk+name(f
ael
info
 vae
saveNSci,c&org__tid ,c&org_params	se e {
		f
ael
info
 vaeNSci,c vae nt parsjec;ek}mrnasulte Ival_p
ael
, "WrongNfciP(Sccsobj->object)	}
			!ret "u-_st-_ste&& ret "u	walk+z "u-_st-dtmp	&ret "u	res}
	+;
	 vae	walk+name(f
ael
info
 vae
restoreNfciP(org__tid ,corg_params	se })-name = result	*param = (zval **) p-(aonst cnd_wroname(aet_moduIS_versongNcnst cnd_wromoduIS_n) {) g_object_to_shar **lpara;ckt't  ame||
	n;
str|
	emoduIS_n) {);_sunt--moduIS_L classmoduISt)	}lS) {e Ival_ps;

	oloweEN_upemoduIS_n) {,  ame||
	*); P;
	val_phash
find(&moduIS_regis;
y, ln) {,  ame||
	*+	1, (s_araa)&moduIS)e 		TRVAL_Po		*p  Z_STRlpara)se ename = j->fre
} ' Z_STRlS) {ct)-name = moduIS->versongacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtyt,x( {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,c	 "unkeaoasrty}}
	re cceec_tic (*ING zend_wrodoc_commed ,c
	redoc_commed _|
	ent parse_arg_object_to_sunt--eaoasrtytinfo
eaoasrtytinfo,nkeaoasrty
info
_st;e
ING zend_wroPIr;

edmpara;cke	}

	he Ival_pget-hash
 "uue( ame, S) {_CE_P(o+1ct)	}
			!( cceec_tic n&_ucharACC_PPP_MASKp)n{)-= cceec_tic n| =ucharACC_PUBLICres}
	+;
	 cceec_tic n&_ucharACC_	bATIC) {)-=P;
	val_phash
ryick
find(&cs->eaoasrtiestinfo,n ame, S) {_CE_P(o*+	1, h, (s_araa)&eaoasrty
info
_stce 					if (e);_st   |(eaoasrty
info
_st->mentin&_ucharACC_	bATICy !=			walk+	eaoasrty
info.offsame Ieaoasrty
info
_st->offsam;)-=en "u__st-dtmp	&cs->default_zend_g_mject)stterou[eaoasrty
info.offsam]	se e'val_phash
ryick
del(&cs->eaoasrtiestinfo,n ame, S) {_CE_P(o*+	1, hct)-=}NOT_REF(argeaoasrty
info.offsame Ics->default_zend_g_mject)st tid walk e_cS->default_zend_g_mject)stteroue Ieste(zval cS->default_zend_g_mject)stterou, eobject, "uk)}*Ics->default_zend_g_mject)st tid , _s->	case = on_naINTERNE:
CLASS	se e}0=ecs->default_zend_g_mject)stterou[eaoasrty
info.offsam]e Ieaoasrty;ek	+;
	cn->	case = on_naUSER
CLASS	w{k e_cS->zend_g_mject)stteroue Ics->default_zend_g_mject)stterou;e

}y:}NOT_RE{
-=P;
	val_phash
ryick
find(&cs->eaoasrtiestinfo,n ame, S) {_CE_P(o*+	1, h, (s_araa)&eaoasrty
info
_stce 					if (e);_st   |(eaoasrty
info
_st->mentin&_ucharACC_	bATICy ==			walk+	eaoasrty
info.offsame Ieaoasrty
info
_st->offsam;)-=en "u__st-dtmp	&cs->default_eaoasrtiestterou[eaoasrty
info.offsam]	se e'val_phash
ryick
del(&cs->eaoasrtiestinfo,n ame, S) {_CE_P(o*+	1, hct)-=}NOT_REF(argeaoasrty
info.offsame Ics->default_eaoasrtiest tid walk e_cS->default_eaoasrtiestteroue Ieste(zval cS->default_eaoasrtiestterou, eobject, "uk)}*Ics->default_eaoasrtiest tid , _s->	case = on_naINTERNE:
CLASS	se e}0=ecs->default_eaoasrtiestterou[eaoasrty
info.offsam]e Ieaoasrty;ek} 
+;
	_s->	case& on_naINTERNE:
CLASS	walk+switch	Zd_boolP(eaoasrtyp)n{)-=ecaae IS ARRAY:(argcaae IS OBJECT:(argcaae IS RESOURCE:
=ere {
		st char CORr ERRORnamI= N

_Se, "u'slg( }}}bndarrays,Iobjct s
ch
resourcee"pse e'
	casese e'default:(arg
	casese e}e
} 'switch
( cceec_tic n&_ucharACC_PPP_MASKpheck_caae ucharACC_PRIVATE:walk+		_d_wro_rS__para;cke'	
	re_rS__para_CE_P(o_mlk+k+name(mangle	eaoasrtytparam&_rS__para, &_rS__para_CE_P(o,ecs->S) {, _s->S) {_CE_P(o,n ame, S) {_CE_P(o, _s->	case& on_naINTERNE:
CLASS	se ergeaoasrty
info.S) {e I_rS__para;cke'	eaoasrty
info.S) {_CE_P(o*=e_rS__para_CE_P(o_m e'}
r=e	casese ecaae ucharACC_PROTECTED:walk+		_d_wro_rot_para;cke'	
	re_rot_para_CE_P(o_mlk+k+name(mangle	eaoasrtytparam&_rot_para, &_rot_para_CE_P(onam*"}}1IL ame, S) {_CE_P(o, _s->	case& on_naINTERNE:
CLASS	se ergeaoasrty
info.S) {e I_rot_para;cke'	eaoasrty
info.S) {_CE_P(o*=e_rot_para_CE_P(o_m e'}
r=e	casese ecaae ucharACC_PUBLIC:(argPJ_HIS INTERNED( ame)) {)-=k+eaoasrty
info.S) {e I)nd_w*)para;cke'}NOT_RE{)-=ereaoasrty
info.S) {e I_s->	case& on_naINTERNE:
CLASSe?	val_ps;
n_upeS) {,  ame||
	P(o)e: es;
n_upeS) {,  ame||
	P(o)_m e'}
r=eeaoasrty
info.S) {_CE_P(o*=epara_CE_P(o_m e'	casese ss
++Ir;

edmparae Ival_pnew_+Ir;

edm		retureaoasrty
info.S) {, eaoasrty
info.S) {_CE_P(o+1IL0int pars*spacgPJ_H+Ir;

edmparae!= eaoasrty
info.S) {) {)-=P;
	cn->	case = on_naUSER
CLASS	w{k e_ Z_STR)nd_w*)eaoasrty
info.S) {)t)-=}NOT_RE{)-=eS_STR)nd_w*)eaoasrty
info.S) {)t)-=}
ereaoasrty
info.S) {e IPIr;

edmpara;ckss
+eaoasrty
info.mentin = cceec_tic ;
+eaoasrty
info.o*=e( cceec_tic n&_ucharACC_PUBLIC	w? he: val_pget-hash
 "uue(eaoasrty
info.S) {, eaoasrty
info.S) {_CE_P(o+1ct)	}eaoasrty
info.doc_commed 
=gdoc_commed ;	}eaoasrty
info.doc_commed ||
	n;
doc_commed ||
	t)	}eaoasrty
info.c{e I_s;m cval_phash
ryick
upatoe(&cs->eaoasrtiestinfo,n ame, S) {_CE_P(o+1, h, &eaoasrtytinfo,neobject,menteaoasrtytinfo)zvj->f)re	}reme = ***);
		*param = (zval **) p-(a
	re {
		declare	eaoasrty( {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,c	 "unkeaoasrty}}
	re cceec_tic int parse_arg_object_to_srg_coun {
		declare	eaoasrtyt,x(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic (*j->fP(0int pars*spacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtytnull( {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,c
	re cceec_tic int parse_arg_object_to_s	 "unkeaoasrty;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(eaoasrtyp;ee}NOT_REF(arALLOC_ZVAL(eaoasrtyp;ee});INIT_ZVAL(*eaoasrtyp;eerg_coun {
		declare	eaoasrty(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic int pars*spacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtytbool( {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,c	}

	 "uue,c
	re cceec_tic int parse_arg_object_to_s	 "unkeaoasrty;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(eaoasrtyp;ee}NOT_REF(arALLOC_ZVAL(eaoasrtyp;ee});INIT_PZVAL(eaoasrtyp;eeZVAL_BOOL(eaoasrty,	 "uuep;eerg_coun {
		declare	eaoasrty(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic int pars*spacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtyt	}

( {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,c	}

	 "uue,c
	re cceec_tic int parse_arg_object_to_s	 "unkeaoasrty;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(eaoasrtyp;ee}NOT_REF(arALLOC_ZVAL(eaoasrtyp;ee});INIT_PZVAL(eaoasrtyp;eeZVAL_LONG(eaoasrty,	 "uuep;eerg_coun {
		declare	eaoasrty(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic int pars*spacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtytdourou( {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,cdourou	 "uue,c
	re cceec_tic int parse_arg_object_to_s	 "unkeaoasrty;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(eaoasrtyp;ee}NOT_REF(arALLOC_ZVAL(eaoasrtyp;ee});INIT_PZVAL(eaoasrtyp;eeZVAL_DOUBLE(eaoasrty,	 "uuep;eerg_coun {
		declare	eaoasrty(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic int pars*spacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtyt		retur {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,cING zend_wro "uue,c
	re cceec_tic int parse_arg_object_to_s	 "unkeaoasrty;_	
	re|
	n;
str|
	e "uuep;e

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(eaoasrtyp;eeeZVAL_	breakL(eaoasrty,	val_ps;
n_upe "uue,c|
	*,c|
	P(0p;ee}NOT_REF(arALLOC_ZVAL(eaoasrtyp;eeeZVAL_	breakL(eaoasrty,	 "uue,c|
	,c1)res});INIT_PZVAL(eaoasrtyp;eerg_coun {
		declare	eaoasrty(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic int pars*spacparam = (zval **) p-(a		ca,mentdeclare	eaoasrtyt		retulr {
		object, class_e, ING zend_wroS) {,et't  ame||
	P(o,cING zend_wro "uue,c
	re "uue||
	,c
	re cceec_tic int parse_arg_object_to_s	 "unkeaoasrty;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(eaoasrtyp;eeeZVAL_	breakL(eaoasrty,	val_ps;
n_upe "uue,c "uue||
	),e "uue||
	,c0p;ee}NOT_REF(arALLOC_ZVAL(eaoasrtyp;eeeZVAL_	breakL(eaoasrty,	 "uue,c "uue||
	,c1)res});INIT_PZVAL(eaoasrtyp;eerg_coun {
		declare	eaoasrty(ceIL ame, S) {_CE_P(o, eaoasrty}} cceec_tic int pars*spacparam = (zval **) p-(a		ca,mentdeclare	objectING zantr {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(o,c	 "unk "uueint parse_arg_object_to_srg_coun {
		hash
upatoe(&cs->ING zantstterou,  ame, S) {_CE_P(o+1, & "uue,ceobject, "unk)zvj->f)reparam = (zval **) p-(a		ca,mentdeclare	objectING zanttnull( {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(oint parse_arg_object_to_s	 "unkING zant;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(ING zantp;ee}NOT_REF(arALLOC_ZVAL(ING zantp;ee}eeZVAL_j->f(ING zantp;eeINIT_PZVAL(ING zantp;eerg_coun {
		declare	objectING zantrceIL ame, S) {_CE_P(o, ING zantint pars*spacparam = (zval **) p-(a		ca,mentdeclare	objectING zantt	}

( {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(o,c	}

	 "uueint parse_arg_object_to_s	 "unkING zant;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(ING zantp;ee}NOT_REF(arALLOC_ZVAL(ING zantp;ee}eeZVAL_LONG(ING zant,	 "uuep;eeINIT_PZVAL(ING zantp;eerg_coun {
		declare	objectING zantrceIL ame, S) {_CE_P(o, ING zantint pars*spacparam = (zval **) p-(a		ca,mentdeclare	objectING zanttbool( {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(o,c	mentboole "uueint parse_arg_object_to_s	 "unkING zant;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(ING zantp;ee}NOT_REF(arALLOC_ZVAL(ING zantp;ee}eeZVAL_BOOL(ING zant,	 "uuep;eeINIT_PZVAL(ING zantp;eerg_coun {
		declare	objectING zantrceIL ame, S) {_CE_P(o, ING zantint pars*spacparam = (zval **) p-(a		ca,mentdeclare	objectING zanttdourou( {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(o,cdourou	 "uueint parse_arg_object_to_s	 "unkING zant;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(ING zantp;ee}NOT_REF(arALLOC_ZVAL(ING zantp;ee}eeZVAL_DOUBLE(ING zant,	 "uuep;eeINIT_PZVAL(ING zantp;eerg_coun {
		declare	objectING zantrceIL ame, S) {_CE_P(o, ING zantint pars*spacparam = (zval **) p-(a		ca,mentdeclare	objectING zantt		retulr {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(o,cING zend_wro "uue,ceobj_t  "uue||
	P(oint parse_arg_object_to_s	 "unkING zant;_

+;
	_s->	case& on_naINTERNE:
CLASS	walk+ALLOC_PERMANENT_ZVAL(ING zantp;eeeZVAL_	breakL(ING zant,	val_ps;
n_upe "uue,c "uue||
	P(o),c "uue||
	P(o,c0p;ee}NOT_REF(arALLOC_ZVAL(ING zantp;eeeZVAL_	breakL(ING zant,	 "uue,c "uue||
	P(o,c1)res});INIT_PZVAL(ING zantp;eerg_coun {
		declare	objectING zantrceIL ame, S) {_CE_P(o, ING zantint pars*spacparam = (zval **) p-(a		ca,mentdeclare	objectING zantt		retur {
		object, class_e, ING zend_wroS) {,eeobj_t  ame||
	P(o,cING zend_wro "uueint parse_arg_object_to_srg_coun {
		declare	objectING zantt		retulrceIL ame, S) {_CE_P(o,  "uue,cetr|
	e "uuepint pars*spacparam = (zval **) p-(al(argumentupatoe	eaoasrty( {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,c	 "unk "uueint parse_arg_object_to_s	 "unkeaoasrty;_	 {
		object, classold_scoase		\
	scoasc;e
e\
	scoascn=bscoasrect
			!Z_OBJ_HT_P(objct )->wrioe	eaoasrty	walk+cost cnd_wrocbjectpara;ckeumentu
	re_|jectpara||
	t)	}	val_pget-objct -_|jecparamobjct , &_|jectpara, &_|jectpara_|
	int parsject)
re {
		st char CORr ERRORnamPaoasrty %s	oflobjece%slg( no/lbe upatoed"IL ame, _|jectpara)res});MAKE_	bD_ZVAL(eaoasrtyp;eeZVAL_	breakL(eaoasrty,	 ame, S) {_CE_P(o, 1)resZ_OBJ_HT_P(objct )->wrioe	eaoasrtymobjct , eaoasrty,	 "uue,c0int pars*spacgn "u__st-dtmp	&eaoasrtyp;e
e\
	scoascn=bold_scoasacparam = (zval **) p-(al(argumentupatoe	eaoasrtytnull( {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(oint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_j->f(tmp)resumentupatoe	eaoasrty(scoas, objct ,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(al(argumentupatoe	eaoasrtytbool( {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,c	}

	 "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_BOOL(tmp,c "uuep;eeumentupatoe	eaoasrty(scoas, objct ,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(al(argumentupatoe	eaoasrtyt	}

( {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,c	}

	 "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_LONG(tmp,c "uuep;eeumentupatoe	eaoasrty(scoas, objct ,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(al(argumentupatoe	eaoasrtytdourou( {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,cdourou	 "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_DOUBLE(tmp,c "uuep;eeumentupatoe	eaoasrty(scoas, objct ,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(al(argumentupatoe	eaoasrtyt		retur {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,cING zend_wro "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_	break(tmp,c "uue, 1)resumentupatoe	eaoasrty(scoas, objct ,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(al(argumentupatoe	eaoasrtyt		retulr {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,cING zend_wro "uue,c
	re "uue||
	int parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_	breakL(tmp,c "uue,  "uue||
	,c1)resumentupatoe	eaoasrty(scoas, objct ,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrty( {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,c	 "unk "uueint parse_arg_object_to_s	 "unkkeaoasrty;_	 {
		object, classold_scoase		\
	scoasc;e
e\
	scoascn=bscoasre}eaoasrtye		val_ps;d
aet_zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, 0zvj->feobj->objec;ek\
	scoascn=bold_scoasact
			!eaoasrty	walk+rg_count = (int)(}NOT_RE{
-=P;
	keaoasrtye!=  "uuepi{)-=eBJ_HPZVAL_IS REF(*eaoasrtyp) {)-=

n "u-dtmp	*eaoasrtyp;eea__Zd_boolPP(eaoasrty	w=
Zd_boolP( "uuep;eesta(*eaoasrtyp-> "uuei=  "uue-> "uuere
e=eif (Z_REFCOUNT_P( "uuepi>			walk+		-n "u- *ne_ctmp	*eaoasrtyp;eea__}NOT_RE{)-=ere Z_STR "uuep;eesta}cke'}NOT_RE{)-=er	 "unkgarbagei= keaoasrty;_

a__ZdADDREF_P( "uuep;eestaBJ_HPZVAL_IS REF( "uuep	walk+		-SEPARATE_ZVAL(& "uuep;eesta}cke'	*eaoasrtye		 "uuere
e=en "u__st-dtmp	&garbage);
 e'}e

}
rpname = ***);
		*-ssparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrtytnull( {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(oint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_j->f(tmp)resrg_coun {
		upatoe	zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrtytbool( {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,c	}

	 "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_BOOL(tmp,c "uuep;eerg_coun {
		upatoe	zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrtyt	}

( {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,c	}

	 "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_LONG(tmp,c "uuep;eerg_coun {
		upatoe	zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrtytdourou( {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,cdourou	 "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_DOUBLE(tmp,c "uuep;eerg_coun {
		upatoe	zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrtyt		retur {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,cING zend_wro "uueint parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_	break(tmp,c "uue, 1)resrg_coun {
		upatoe	zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a		ca,mentupatoe	zend_g_eaoasrtyt		retulr {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,cING zend_wro "uue,c
	re "uue||
	int parse_arg_object_to_s	 "unktmp;e
eALLOC_ZVAL(tmp)resZ_UNSET_ISREF_P(tmp)resZ_SET_REFCOUNT_P(tmp,c0p;eeZVAL_	breakL(tmp,c "uue,  "uue||
	,c1)resrg_coun {
		upatoe	zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, tmpint pars*spacparam = (zval **) p-(a	 "unk {
		read	eaoasrty( {
		object, classscoas, 	 "unkobjct , ING zend_wroS) {,et't  ame||
	P(o,c	mentboolesilentint parse_arg_object_to_s	 "unkeaoasrty,ro "uue;_	 {
		object, classold_scoase		\
	scoasc;e
e\
	scoascn=bscoasrect
			!Z_OBJ_HT_P(objct )->read	eaoasrty	walk+cost cnd_wrocbjectpara;ckeumentu
	re_|jectpara||
	t)	}	val_pget-objct -_|jecparamobjct , &_|jectpara, &_|jectpara_|
	int parsject)re {
		st char CORr ERRORnamPaoasrty %s	oflobjece%slg( no/lbe read"IL ame, _|jectpara)res}));MAKE_	bD_ZVAL(eaoasrtyp;eeZVAL_	breakL(eaoasrty,	 ame, S) {_CE_P(o, 1)res "uuei= Z_OBJ_HT_P(objct )->read	eaoasrtymobjct , eaoasrty,	silent?BP_VAR_IS:BP_VAR_R,c0int pars*spacgn "u__st-dtmp	&eaoasrtyp;e
e\
	scoascn=bold_scoasacsrg_coun "uue;_param = (zval **) p-(a	 "unk {
		read	zend_g_eaoasrty( {
		object, classscoas, ING zend_wroS) {,et't  ame||
	P(o,c	mentboolesilentint parse_arg_object_to_s	 "unkkeaoasrty;_	 {
		object, classold_scoase		\
	scoasc;e
e\
	scoascn=bscoasre}eaoasrtye		val_ps;d
aet_zend_g_eaoasrty(scoas,  ame, S) {_CE_P(o, silentzvj->feobj->objec;ek\
	scoascn=bold_scoasaccsrg_couneaoasrty?keaoasrty:j->freparam = (zval **) p-(al(argumentsave	st cht no retur {
		st cht no returoctor */int parse_arg_object_to_sctor */-> no retur		\
	st cht no retuc;ekctor */->excepESS;
 I\
	sxcepESS;	objecc;ekctor */->usert no reae		\
	usertst cht no reapse +;
	_tor */->usert no rea	walk+ZdADDREF_P(_tor */->usert no rea		*-ssparam = (zval **) p-(al(argumentreplace	st cht no retur {
		st cht no retu_t st cht no retu,c	mentobject, classsxcepESS;	objec,c	mentst cht no returoctor */int parse_arg_object_to_s+;
	_tor */	walk+name(save	st cht no returctor */int parsject)rePJ_Hst cht no retur!		\H_NORMALe&& \
	usertst cht no reap)n{)-=en "u__st-dtmp	&\
	usertst cht no reap);
 e'\
	usertst cht no reape		j->fres=}e
} '\
	st cht no retuc
= et cht no retu;ek\
	sxcepESS;	objecc
= et cht no retui== rH_THROW ? sxcepESS;	objec :	j->freparam = (zval **) p-(al(argumentrestore	st cht no retur {
		st cht no returosavedint parse_arg_object_to_s\
	st cht no retuc
= saved-> no retu;ek\
	sxcepESS;	objecc
= saved-> no retui== rH_THROW ? saved->excepESS;
:	j->fresPbre	aved->usert no rea	&& 	aved->usert no rear!		\
	usertst cht no reap)n{)-=P			\
	usertst cht no reap)n{)-=en "u__st-dtmp	&\
	usertst cht no reap);
 e}
rp\
	usertst cht no reape			aved->usert no rea;y:}NOT_REif (	aved->usert no rea	walk+z "u-_st-dtmp	&	aved->usert no rea	res});	aved->usert no rear		j->freparam = (zval **) p-(aING zend_w*c	{
		fi
		aliactparar {
		object, class_e, ING zend_wroS) {,eumentu
	re|
	)rg_object_to_sunt--trait	aliac *aliac}}kkaliact_st;e)-+;
	(aliact_ste I_s->	rait	aliacesp)n{)-= liac = kaliact_st;e	- = *spealiacpi{)-=eBJ_Haliac->aliact|
	 ;=a|
	 );_stat!s;
ncaaecmpeS) {, aliac->aliac, aliac->aliac||
	)	walk+		rg_counaliac->aliac_m e'}
r=ealiact_stwalk e_ liac = kaliact_st;e	-}e };	}reme = para;cparam = (zval **) p-(aING zend_w*c	{
		resolvTTme gettparar {
		object, class_e, 	{
		fUCCESS;
*f	wg_object_to_sumentfUCCESS;
*fUCC;_s staPosiESS;
iteratmp;_s staTeroue*SUCCESS;tterout)
	+;
	S->common.	case! =ucharUSER
FUNCTIONs||ck   |*	S->op_array.ref tid ) < 2s||ck   |!f->common.scoass||ck   |!f->common.scoas->	rait	aliacespwalk+rg_counf->common., "Wrong parat)(})e
SUCCESS;tterour= &cs->SUCCESS;tterout)cval_phash
inr;

_STpoinr;

reset_,x(SUCCESS;tterou, &iteratmpct)- = *speval_phash
aet_ctor */aator_,x(SUCCESS;tterou, (s_arraa)&SUCC, &iteratmpce 					if (parse_+;
	SUCCe 		f)n{)-=ecd_wroS) {lk e_u
	re|
	lk e_u	}

	idx;_

a_P;
	val_phash
aet_ctor */akey_,x(SUCCESS;tterou, &para, &|
	,c&idx, 0zv&iteratmpce! =HASH_KEY_IS 	break)r{)-=eerg_counf->common., "Wrong parat)(e'}
r=e--|
	lk e_P;
	|
	 ;=aetr|
	ef->common., "Wrong para)s);_sta   |!s;
ncaaecmpeS) {, f->common., "Wrong para, |
	)	walk+		rg_counf->common., "Wrong parat)(e'}
r=erg_coun {
		fi
		aliactpararf->common.scoas}}para, |
	);
 e}
rpval_phash
mo_e_,orward_,x(SUCCESS;tterou, &iteratmpct)-})-name = f->common., "Wrong parat)param = (zval/*
 * Loc"usvarierous:
 * ter-width: 4
 * c-basic-offsam: 4
 * inde*/-ters-mode: t
 * End:
 */
                                                                      