#set dump dur longer
dump_dur=15