#test uses rand() cannot hash playback
skip_play_hash=1


