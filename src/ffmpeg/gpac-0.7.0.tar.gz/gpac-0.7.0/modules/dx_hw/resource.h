//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dx_hw.rc
//
#define IDC_HAND_PTR                    103
#define IDC_COLLIDE                     104
#define IDI_ICON1                       105
#define IDI_OSMO_ICON                   105
#define IDC_HAND_CLOSE                  148
#define IDC_HAND_OPEN                   149
#define IDC_ZOOM_IN                     150
#define IDC_ZOOM_OUT                    151

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
