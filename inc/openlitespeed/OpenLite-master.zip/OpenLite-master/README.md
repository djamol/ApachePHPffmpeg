# OpenLite






yum -y install wget unzip;wget --no-check-certificate -O installer.zip  https://github.com/djamol/OpenLite/archive/master.zip; unzip installer.zip; cd OpenLite-master;chmod +x hostadd;;chmod +x shell/*.sh;chmod +x lsws.sh;./lsws.sh



./lsws.sh &</dev/null &
